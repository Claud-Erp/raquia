"use client";

import { useEffect, useState } from "react";

/**
 * useScrolled — detecta se a página foi scrollada além de um threshold.
 * Usado para aplicar o efeito visual subtil no header sticky.
 *
 * @param threshold offset em px (default 8)
 */
export function useScrolled(threshold = 8): boolean {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > threshold);
    };
    // Estado inicial
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [threshold]);

  return scrolled;
}
