"use client";

import { useEffect, useState } from "react";
import { navItems } from "@/config/navigation";

/**
 * useActiveSection — detecta qual secção está actualmente visível no viewport.
 * Usa IntersectionObserver para performance.
 * Retorna o `section` id da secção activa (ex: "inicio", "servicos").
 */
export function useActiveSection(): string | null {
  const [active, setActive] = useState<string | null>("inicio");

  useEffect(() => {
    const sections = navItems
      .map((item) => item.section)
      .filter(Boolean)
      .map((id) => document.getElementById(id as string))
      .filter((el): el is HTMLElement => Boolean(el));

    if (sections.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        // Procura a entrada mais visível
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);

        if (visible[0]) {
          setActive(visible[0].target.id);
        }
      },
      {
        // Margem que considera a secção "activa" antes de chegar ao topo
        rootMargin: "-40% 0px -55% 0px",
        threshold: [0, 0.1, 0.25, 0.5, 0.75, 1],
      }
    );

    sections.forEach((section) => observer.observe(section));

    return () => observer.disconnect();
  }, []);

  return active;
}
