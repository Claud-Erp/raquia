"use client";

import * as React from "react";

/**
 * useHeroCarousel — gere o carrossel de slides do Hero.
 *
 * Funcionalidades:
 * - Auto-play (interval configurável, default 6s)
 * - Pausa quando o utilizador está a interagir (hover/focus)
 * - Navegação manual (próximo/anterior/índice directo)
 * - Loop infinito
 * - Respeita prefers-reduced-motion (não faz auto-play)
 */
export function useHeroCarousel(count: number, interval = 6000) {
  const [current, setCurrent] = React.useState(0);
  const [isPaused, setIsPaused] = React.useState(false);
  const timerRef = React.useRef<ReturnType<typeof setInterval> | null>(null);

  // Respeitar prefers-reduced-motion: sem auto-play
  const prefersReducedMotion = React.useMemo(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  const next = React.useCallback(() => {
    setCurrent((prev) => (prev + 1) % count);
  }, [count]);

  const prev = React.useCallback(() => {
    setCurrent((prev) => (prev - 1 + count) % count);
  }, [count]);

  const goTo = React.useCallback((index: number) => {
    setCurrent(index);
  }, []);

  // Auto-play
  React.useEffect(() => {
    if (prefersReducedMotion || isPaused || count <= 1) return;

    timerRef.current = setInterval(() => {
      setCurrent((prev) => (prev + 1) % count);
    }, interval);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [prefersReducedMotion, isPaused, count, interval]);

  const pause = React.useCallback(() => setIsPaused(true), []);
  const resume = React.useCallback(() => setIsPaused(false), []);

  return {
    current,
    next,
    prev,
    goTo,
    pause,
    resume,
    isPaused,
  };
}
