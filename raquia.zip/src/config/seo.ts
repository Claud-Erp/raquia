export const siteUrl = "https://raquiagrafica.ao";

export const seoConfig = {
  title: { default: "RAQUIA GRÁFICA — Impressão & Comunicação Visual Premium | Angola", template: "%s · RAQUIA GRÁFICA" },
  description: "Gráfica profissional em Luanda especializada em impressão, comunicação visual, materiais corporativos, brindes personalizados e embalagens. Solicite o seu orçamento.",
  keywords: ["gráfica Angola","gráfica Luanda","impressão gráfica Angola","impressão gráfica Luanda","cartões de visita Angola","flyers Angola","banners Angola","brindes personalizados Angola","embalagens personalizadas Angola","comunicação visual Angola","materiais corporativos Angola","timbragem camisolas Angola","roll-up Angola","catálogos Angola","RAQUIA GRÁFICA","gráfica premium Angola","impressão digital Angola","serigrafia Angola","sinalética Angola","packaging Angola"],
  authors: [{ name: "RAQUIA GRÁFICA" }],
  creator: "RAQUIA GRÁFICA",
  publisher: "RAQUIA GRÁFICA",
  metadataBase: siteUrl,
  alternates: { canonical: "/", languages: { "pt-AO": "/", "pt-PT": "/" } },
  openGraph: { type: "website", locale: "pt_AO", url: siteUrl, siteName: "RAQUIA GRÁFICA", title: "RAQUIA GRÁFICA — Impressão & Comunicação Visual Premium | Angola", description: "Gráfica profissional em Luanda especializada em impressão, comunicação visual, materiais corporativos, brindes e embalagens. Solicite o seu orçamento.", images: [{ url: "/hero/hero-main.png", width: 864, height: 1152, alt: "Materiais gráficos premium produzidos pela RAQUIA GRÁFICA em Luanda, Angola" }] },
  twitter: { card: "summary_large_image", title: "RAQUIA GRÁFICA — Impressão & Comunicação Visual Premium | Angola", description: "Gráfica profissional em Luanda. Impressão, comunicação visual, brindes e embalagens premium.", images: ["/hero/hero-main.png"], creator: "@raquiagrafica" },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, "max-video-preview": -1, "max-image-preview": "large", "max-snippet": -1 } },
  icons: { icon: "/logo.svg", shortcut: "/logo.svg", apple: "/logo.svg" },
  verification: { google: "GOOGLE_SEARCH_CONSOLE_VERIFICATION_CODE" },
  category: "Printing Services",
};

export const schemaOrg = {
  "@context": "https://schema.org",
  "@type": "PrintShop",
  "@id": `${siteUrl}/#business`,
  name: "RAQUIA GRÁFICA",
  alternateName: "Raquia Gráfica",
  description: "Gráfica profissional especializada em impressão, comunicação visual, materiais corporativos, brindes, embalagens e soluções personalizadas em Angola.",
  url: siteUrl,
  logo: `${siteUrl}/logo.svg`,
  image: `${siteUrl}/hero/hero-main.png`,
  telephone: "+244900000000",
  email: "geral@raquiagrafica.ao",
  priceRange: "$$",
  currenciesAccepted: "AOA, USD, EUR",
  paymentAccepted: "Cash, Transferência Bancária, Multicaixa Express",
  address: { "@type": "PostalAddress", streetAddress: "Rua Comercial, Edifício Raquia, Maianga", addressLocality: "Luanda", addressRegion: "Luanda", postalCode: "", addressCountry: "AO" },
  geo: { "@type": "GeoCoordinates", latitude: -8.8147, longitude: 13.2302 },
  openingHoursSpecification: [{ "@type": "OpeningHoursSpecification", dayOfWeek: ["Monday","Tuesday","Wednesday","Thursday","Friday"], opens: "08:00", closes: "18:00" }, { "@type": "OpeningHoursSpecification", dayOfWeek: "Saturday", opens: "09:00", closes: "13:00" }],
  areaServed: { "@type": "Country", name: "Angola" },
  sameAs: ["https://instagram.com/raquiagrafica","https://facebook.com/raquiagrafica","https://linkedin.com/company/raquiagrafica"],
  hasOfferCatalog: { "@type": "OfferCatalog", name: "Serviços RAQUIA GRÁFICA", itemListElement: [{ "@type":"Offer", itemOffered:{ "@type":"Service", name:"Impressão Gráfica", description:"Cartões, flyers, catálogos, brochuras e muito mais." } },{ "@type":"Offer", itemOffered:{ "@type":"Service", name:"Materiais Corporativos", description:"Papel timbrado, cartões, envelopes, agendas e cadernos." } },{ "@type":"Offer", itemOffered:{ "@type":"Service", name:"Comunicação Visual", description:"Banners, roll-ups, outdoors, placas e sinalética." } },{ "@type":"Offer", itemOffered:{ "@type":"Service", name:"Brindes Personalizados", description:"Presentes corporativos personalizados com a sua marca." } },{ "@type":"Offer", itemOffered:{ "@type":"Service", name:"Packaging & Embalagens", description:"Caixas, sacos, rótulos e soluções de embalagem personalizadas." } },{ "@type":"Offer", itemOffered:{ "@type":"Service", name:"Timbragem & Estampagem", description:"Timbragem e estampagem de camisolas e têxteis." } },{ "@type":"Offer", itemOffered:{ "@type":"Service", name:"Grande Formato", description:"Banners, placas, acrílicos e sinalética de grande formato." } }] },
};

export const breadcrumbSchema = { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Início", item: siteUrl }] };
