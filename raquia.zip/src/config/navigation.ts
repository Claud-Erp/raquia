/**
 * Navegação central da RAQUIA GRÁFICA.
 * Itens do menu (desktop e mobile) lêem desta fonte única.
 *
 * Cada item aponta para uma secção da home via anchor (#id)
 * para scroll suave. URLs reais podem ser adicionadas futuramente.
 */

export interface NavItem {
  label: string;
  href: string;
  /** Secção alvo para scroll suave (sem #) */
  section?: string;
}

export const navItems: NavItem[] = [
  { label: "Início", href: "/#inicio", section: "inicio" },
  { label: "Sobre", href: "/#sobre", section: "sobre" },
  { label: "Serviços", href: "/#servicos", section: "servicos" },
  { label: "Produtos", href: "/#produtos", section: "produtos" },
  { label: "Portfólio", href: "/#portfolio", section: "portfolio" },
  { label: "Orçamento", href: "/#orcamento", section: "orcamento" },
  { label: "Contactos", href: "/#contactos", section: "contactos" },
];

export const primaryNavItems = navItems.slice(0, 4);
export const secondaryNavItems = navItems.slice(4);
