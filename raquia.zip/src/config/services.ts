/**
 * Configuração dos serviços RAQUIA GRÁFICA.
 *
 * Conteúdo editável — pronto para ligação futura a CMS/backend.
 * Cada serviço tem: id, número, título, descrição, imagem, link
 * e detalhes para o modal (características, aplicações, formatos).
 */

export interface ServiceDetail {
  /** Lista de características/chaves do serviço */
  features: string[];
  /** Aplicações comuns */
  applications: string[];
  /** Formos/materiais disponíveis */
  materials?: string[];
}

export interface Service {
  /** Identificador único (slug) */
  id: string;
  /** Número de ordem editorial (01, 02, ...) */
  number: string;
  /** Título do serviço */
  title: string;
  /** Descrição curta (card) */
  description: string;
  /** Descrição longa (modal) */
  longDescription: string;
  /** Caminho da imagem */
  image: string;
  /** Alt descritivo da imagem (acessibilidade) */
  imageAlt: string;
  /** Link para orçamento */
  href: string;
  /** Detalhes para o modal */
  details: ServiceDetail;
}

export const services: Service[] = [
  {
    id: "impressao-grafica",
    number: "01",
    title: "Impressão Gráfica",
    description:
      "Cartões, flyers, catálogos, brochuras e muito mais. Qualidade fotográfica em cada pormenor.",
    longDescription:
      "A nossa impressão gráfica combina tecnologia de ponta com materiais premium para entregar resultados que comunicam com impacto. Trabalhamos com diferentes gramagens, acabamentos e formatos para dar vida às suas ideias.",
    image: "/services/impressao.png",
    imageAlt:
      "Cartões de visita em papel texturizado preto e branco dispostos em leque",
    href: "/#orcamento",
    details: {
      features: [
        "Impressão digital e offset",
        "Resolução fotográfica até 2400 dpi",
        "Cores CMYK e Pantone",
        "Acabamentos: verniz, plastificação, hot stamping",
      ],
      applications: [
        "Cartões de visita",
        "Flyers e panfletos",
        "Catálogos e brochuras",
        "Convites e certificados",
      ],
      materials: [
        "Couché brilhante/mate",
        "Papel reciclado",
        "Papel texturizado",
        "Cartolina premium",
      ],
    },
  },
  {
    id: "materiais-corporativos",
    number: "02",
    title: "Materiais Corporativos",
    description:
      "Papel timbrado, cartões, envelopes, agendas e cadernos que elevam a imagem da sua empresa.",
    longDescription:
      "Criamos materiais corporativos que transmitem profissionalismo e coesão em cada ponto de contacto com o seu cliente. Da papelaria básica aos cadernos executivos, garantimos consistência visual e qualidade premium.",
    image: "/services/corporativos.png",
    imageAlt:
      "Conjunto de papelaria corporativa: caderno, papel timbrado, envelope e caneta",
    href: "/#orcamento",
    details: {
      features: [
        "Identidade visual consistente",
        "Papelaria completa personalizada",
        "Encadernação profissional",
        "Acabamentos executivos",
      ],
      applications: [
        "Papel timbrado",
        "Cartões corporativos",
        "Envelopes personalizados",
        "Agendas e cadernos executivos",
      ],
      materials: [
        "Papel offset premium",
        "Couro sintético",
        "Cartolina rigidizada",
        "Papel reciclado premium",
      ],
    },
  },
  {
    id: "comunicacao-visual",
    number: "03",
    title: "Comunicação Visual",
    description:
      "Banners, roll-ups, outdoors, placas e sinalética com acabamentos profissionais.",
    longDescription:
      "Desenvolvemos soluções de comunicação visual de grande impacto, desde banners e roll-ups até sinalética interior e exterior. Materiais resistentes e impressão de alta qualidade para garantir visibilidade e durabilidade.",
    image: "/services/comunicacao.png",
    imageAlt:
      "Roll-up, banner e placas de sinalética em acrílico para comunicação visual",
    href: "/#orcamento",
    details: {
      features: [
        "Impressão de grande formato",
        "Materiais resistentes a exterior",
        "Sinalética interior e exterior",
        "Estruturas robustas",
      ],
      applications: [
        "Roll-ups e banners",
        "Outdoors e painéis",
        "Placas e sinalética",
        "Vinis e adesivos",
      ],
      materials: [
        "Lona 440g/m²",
        "Vinil adesivo",
        "Acrílico",
        "PVC expandido",
      ],
    },
  },
  {
    id: "brindes-personalizados",
    number: "04",
    title: "Brindes Personalizados",
    description:
      "Presentes corporativos personalizados com a sua marca para todas as ocasiões.",
    longDescription:
      "Oferecemos uma ampla gama de brindes corporativos personalizados que reforçam a sua marca em cada gesto. Da caneca à garrafa, do saco ao caderno, aplicamos a sua identidade com qualidade duradoura.",
    image: "/services/brindes.png",
    imageAlt:
      "Brindes corporativos: caneca, garrafa térmica, saco de pano e t-shirt personalizados",
    href: "/#orcamento",
    details: {
      features: [
        "Sublimação de alta qualidade",
        "Personalização com a sua marca",
        "Variedade de produtos",
        "Quantidades a partir de 1 unidade",
      ],
      applications: [
        "Canecas e garrafas",
        "Sacos e t-shirts",
        "Canetas e blocos",
        "Kits corporativos",
      ],
      materials: [
        "Cerâmica premium",
        "Aço inoxidável",
        "Algodão 100%",
        "Tecido não-tecido",
      ],
    },
  },
  {
    id: "packaging-embalagens",
    number: "05",
    title: "Packaging & Embalagens",
    description:
      "Caixas, sacos, rótulos e soluções de embalagem personalizadas que valorizam o seu produto.",
    longDescription:
      "Criamos embalagens personalizadas que protegem e valorizam o seu produto. Da caixa rígida ao rótulo premium, desenvolvemos soluções que elevam a experiência do cliente e reforçam a sua marca no ponto de venda.",
    image: "/services/packaging.png",
    imageAlt:
      "Caixas rígidas kraft e pretas, sacola de papel e rótulos de embalagem premium",
    href: "/#orcamento",
    details: {
      features: [
        "Design estrutural personalizado",
        "Prototipagem rápida",
        "Materiais sustentáveis",
        "Acabamentos premium",
      ],
      applications: [
        "Caixas rígidas e dobradas",
        "Sacos de papel personalizados",
        "Rótulos e etiquetas",
        "Embalagens de oferta",
      ],
      materials: [
        "Kraft pardo",
        "Cartolina micro-canal",
        "Papel couché",
        "Materiais recicláveis",
      ],
    },
  },
  {
    id: "timbragem-estampagem",
    number: "06",
    title: "Timbragem & Estampagem",
    description:
      "Timbragem e estampagem de camisolas e têxteis com a sua marca, nome ou símbolo. Qualidade duradoura.",
    longDescription:
      "Aplicamos a sua marca em têxteis através de timbragem e estampagem de alta durabilidade. Trabalhamos com camisolas, polos, casacos e outros tecidos, garantindo cores vivas e resistência a múltiplas lavagens.",
    image: "/hero/hero-slide-4.png",
    imageAlt:
      "Duas camisolas estampadas separadas — uma branca com texto Claudino César e uma preta com símbolo personalizado",
    href: "/#orcamento",
    details: {
      features: [
        "Timbragem e estampagem duradouras",
        "Cores vivas e resistentes à lavagem",
        "Personalização com nome, símbolo ou marca",
        "A partir de 1 peça",
      ],
      applications: [
        "T-shirts e polos",
        "Casacos e fleece",
        "Uniformes de equipa",
        "Brindes têxteis",
      ],
      materials: [
        "Algodão 100% penteado",
        "Misturas algodão/poliéster",
        "Tecidos claros e escuros",
        "Têxteis técnicos",
      ],
    },
  },
  {
    id: "grande-formato",
    number: "07",
    title: "Grande Formato",
    description:
      "Banners, placas, acrílicos e sinalética de grande formato com acabamentos profissionais para qualquer espaço.",
    longDescription:
      "Imprimimos em grande formato para dar máxima visibilidade à sua marca. De painéis de parede a lonas de grande dimensão, cobrimos qualquer necessidade de comunicação visual em espaços amplos.",
    image: "/hero/hero-slide-5.png",
    imageAlt:
      "Materiais de comunicação visual de grande formato — rolos de banner, placas acrílicas e cavaletes",
    href: "/#orcamento",
    details: {
      features: [
        "Impressão até 3,2m de largura",
        "Resistência a exterior (UV e intempérie)",
        "Acabamentos profissionais",
        "Instalação suportada",
      ],
      applications: [
        "Lonas e faixas de grande dimensão",
        "Painéis de parede e fachadas",
        "Sinalética de edifícios",
        "Decoração de espaços",
      ],
      materials: [
        "Lona front/backlit",
        "Vinil micro-perfurado",
        "Acrílico cast",
        "PVC expandido",
      ],
    },
  },
];
