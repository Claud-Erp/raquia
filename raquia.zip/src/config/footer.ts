export interface FooterLink { label: string; href: string; external?: boolean; }

export const footerNav: FooterLink[] = [
  { label: "Início", href: "/#inicio" },
  { label: "Sobre", href: "/#sobre" },
  { label: "Portfólio", href: "/#portfolio" },
  { label: "Orçamento", href: "/#orcamento" },
  { label: "Contactos", href: "/#contactos" },
];

export const footerServices: FooterLink[] = [
  { label: "Impressão Gráfica", href: "/#servicos" },
  { label: "Materiais Corporativos", href: "/#servicos" },
  { label: "Comunicação Visual", href: "/#servicos" },
  { label: "Brindes Personalizados", href: "/#servicos" },
  { label: "Packaging & Embalagens", href: "/#servicos" },
  { label: "Timbragem & Estampagem", href: "/#servicos" },
  { label: "Grande Formato", href: "/#servicos" },
];

export const footerLegal: FooterLink[] = [
  { label: "Política de Privacidade", href: "/politica-de-privacidade" },
  { label: "Termos e Condições", href: "/termos-e-condicoes" },
];

export const footerCatalogs: FooterLink[] = [
  { label: "Catálogo de Serviços", href: "/servicos-raquia-grafica.pdf", external: true },
  { label: "Catálogo de Produtos", href: "/produtos-raquia-grafica.pdf", external: true },
];

export const footerDescription = "Gráfica profissional em Luanda, especializada em impressão premium, comunicação visual e soluções personalizadas para empresas e particulares em Angola.";
export const footerCopyrightYear = new Date().getFullYear();
