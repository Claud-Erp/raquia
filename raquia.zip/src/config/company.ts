/**
 * Configuração institucional da RAQUIA GRÁFICA.
 *
 * Conteúdo editável — pronto para ligação futura a CMS/backend.
 * Inclui: apresentação, estatísticas (com animação), valores.
 */

export interface Stat {
  /** Valor numérico para o contador animado */
  value: number;
  /** Prefixo (ex: "+", não animado) */
  prefix?: string;
  /** Sufixo (ex: "%", não animado) */
  suffix?: string;
  /** Label descritivo */
  label: string;
}

export interface CompanyValue {
  /** Título curto */
  title: string;
  /** Descrição */
  description: string;
}

export const companyInfo = {
  /** Eyebrow / label da secção */
  eyebrow: "Sobre a Raquia",
  /** Headline — linha 1 */
  headlineLine1: "Imprimimos ideias.",
  /** Headline — linha 2 (destaque itálico) */
  headlineLine2: "Materializamos marcas.",
  /** Parágrafo descritivo */
  description:
    "A Raquia Gráfica é uma gráfica moderna e completa, focada em qualidade, agilidade e soluções personalizadas. Apoiamos empresas, instituições e particulares na criação de materiais que comunicam com impacto e profissionalismo.",
  /** CTA */
  cta: {
    label: "Conheça a Raquia",
    href: "/#orcamento",
  },
  /** Imagem institucional */
  image: "/about/grafica-interior.png",
  imageAlt:
    "Interior de uma gráfica moderna com máquinas de impressão e equipamentos de acabamento em espaço minimalista com luz natural",
  /** Legenda da imagem */
  imageCaption: "O nosso atelier · Luanda, Angola",
};

export const stats: Stat[] = [
  { value: 500, prefix: "+", label: "Projectos realizados" },
  { value: 200, prefix: "+", label: "Clientes atendidos" },
  { value: 100, suffix: "%", label: "Foco na qualidade" },
];

export const companyValues: CompanyValue[] = [
  {
    title: "Qualidade",
    description:
      "Materiais premium e acabamento de excelência em cada projecto, do pequeno cartão ao grande formato.",
  },
  {
    title: "Agilidade",
    description:
      "Cumprimos prazos com rigor, sem comprometer a qualidade. Resposta rápida e flexível.",
  },
  {
    title: "Personalização",
    description:
      "Soluções à medida de cada cliente, com atenção aos detalhes que fazem a diferença.",
  },
];

/**
 * Informações detalhadas para o modal "Conheça a Raquia".
 */
export const companyAbout = {
  /** Meta (tag sobre a imagem) */
  meta: "Institucional",
  /** Descrição longa — história/missão */
  longDescription:
    "A Raquia Gráfica nasceu em Luanda com a missão de elevar o padrão de qualidade da indústria gráfica em Angola. Somos uma equipa dedicada de profissionais que combina tecnologia de ponta com artesania cuidada, transformando ideias em materiais tangíveis que comunicam com impacto. Ao longo de mais de uma década, ajudámos centenas de empresas, instituições e particulares a construir marcas fortes e memoráveis.",
  /** Secções de detalhes para o modal */
  sections: [
    {
      title: "Missão",
      items: [
        "Elevar o padrão gráfico em Angola",
        "Apoiar empresas e particulares com soluções premium",
        "Combinar tecnologia e artesania em cada projecto",
      ],
    },
    {
      title: "Visão",
      items: [
        "Ser referência em impressão premium em Angola",
        "Inovar constantemente em materiais e acabamentos",
        "Construir relações duradouras com clientes",
      ],
    },
    {
      title: "Valores",
      items: [
        "Qualidade sem compromissos",
        "Cumprimento rigoroso de prazos",
        "Personalização e atenção ao detalhe",
        "Transparência e confiança",
      ],
    },
  ],
};

