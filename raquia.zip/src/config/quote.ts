export const serviceTypes = ["Impressão Gráfica","Materiais Corporativos","Comunicação Visual","Brindes Personalizados","Packaging & Embalagens","Timbragem & Estampagem","Grande Formato","Outro"] as const;
export const productOptions = ["Cartões de Visita","Flyers e Panfletos","Catálogos e Revistas","Agendas Personalizadas","Sacos Personalizados","T-shirts e Polos","Canecas e Garrafas","Roll-ups e Banners","Outro"] as const;
export const deadlineOptions = ["Expresso (24-48h)","Urgente (3-5 dias)","Normal (7-10 dias)","Flexível (2+ semanas)","A definir"] as const;
export const fileUploadConfig = { maxSizeBytes: 5*1024*1024, maxSizeLabel: "5MB", allowedTypes: ["application/pdf","image/jpeg","image/png","image/webp"], allowedExtensions: [".pdf",".jpg",".jpeg",".png",".webp"], maxFiles: 3 };
export const quoteWhatsAppMessages = { direct: "Olá! Vim pelo site da RAQUIA GRÁFICA e gostaria de solicitar um orçamento. Pode ajudar-me?" };
