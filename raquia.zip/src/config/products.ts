/**
 * Configuração dos produtos RAQUIA GRÁFICA.
 *
 * Conteúdo editável — pronto para ligação futura a CMS/backend.
 * Cada produto tem: id, nome, categoria, imagem, descrição e detalhes para o modal.
 */

export interface ProductDetail {
  /** Descrição longa (modal) */
  longDescription: string;
  /** Especificações técnicas */
  specs: string[];
  /** Opções de personalização */
  options: string[];
}

export interface Product {
  /** Identificador único (slug) */
  id: string;
  /** Nome do produto */
  name: string;
  /** Categoria (para futuros filtros) */
  category: string;
  /** Caminho da imagem */
  image: string;
  /** Alt descritivo (acessibilidade) */
  imageAlt: string;
  /** Descrição curta (card) */
  description?: string;
  /** Link para orçamento */
  href: string;
  /** Detalhes para o modal */
  details: ProductDetail;
}

export const products: Product[] = [
  {
    id: "cartoes-de-visita",
    name: "Cartões de Visita",
    category: "Impressão",
    image: "/products/cartoes-visita.png",
    imageAlt:
      "Cartões de visita em papel texturizado preto e off-white dispostos em leque",
    description: "Papel premium, acabamentos sofisticados.",
    href: "/#orcamento",
    details: {
      longDescription:
        "Cartões de visita em papel premium com acabamentos sofisticados que transmitem profissionalismo à primeira impressão. Disponíveis em várias gramagens e acabamentos.",
      specs: [
        "Gramagens: 300g a 600g",
        "Formatos: 85×55mm, 90×50mm (personalizado)",
        "Acabamentos: mate, brilhante, soft-touch",
        "Cores: impressão a 4/4 cores",
      ],
      options: [
        "Hot stamping (dourado/prata)",
        "Verniz localizado",
        "Plastificação mate/brilhante",
        "Corte especial",
      ],
    },
  },
  {
    id: "flyers-panfletos",
    name: "Flyers e Panfletos",
    category: "Impressão",
    image: "/products/flyers.png",
    imageAlt: "Flyers e panfletos em tons neutros empilhados e em leque",
    description: "Dobras variadas, cores vivas e precisas.",
    href: "/#orcamento",
    details: {
      longDescription:
        "Flyers e panfletos com cores vivas e precisas, disponíveis em várias dobras e formatos. Ideais para campanhas promocionais, eventos e comunicação de massa.",
      specs: [
        "Gramagens: 150g a 350g",
        "Formatos: A6, A5, A4, DL",
        "Dobras: simples, dupla, em Z, em portão",
        "Cores: impressão a 4/4 cores",
      ],
      options: [
        "Verniz mate/brilhante",
        "Plastificação",
        "Corte especial",
        "Papel reciclado",
      ],
    },
  },
  {
    id: "catalogos-revistas",
    name: "Catálogos e Revistas",
    category: "Editorial",
    image: "/products/catalogos.png",
    imageAlt: "Pilha de revistas e catálogos com capa editorial premium",
    description: "Encadernação profissional, papel de alta gramatura.",
    href: "/#orcamento",
    details: {
      longDescription:
        "Catálogos e revistas com encadernação profissional e papel de alta gramatura. Soluções editoriais completas para apresentar os seus produtos com impacto e qualidade.",
      specs: [
        "Encadernação: lombada quadrada, canoa, wire-o",
        "Páginas: a partir de 8",
        "Formatos: A5, A4, personalizado",
        "Papel capa: 250g a 350g",
      ],
      options: [
        "Capa com plastificação",
        "Verniz localizado na capa",
        "Páginas interiores em couché",
        "Inserção de separadores",
      ],
    },
  },
  {
    id: "agendas-personalizadas",
    name: "Agendas Personalizadas",
    category: "Corporativo",
    image: "/products/agendas.png",
    imageAlt: "Agenda de couro com capa gravada e caneta em cima",
    description: "Capas em couro, personalização com a sua marca.",
    href: "/#orcamento",
    details: {
      longDescription:
        "Agendas executivas com capas em couro e personalização com a sua marca. Ideais para ofertas corporativas e para reforçar a imagem da empresa junto dos seus colaboradores e clientes.",
      specs: [
        "Formatos: A5, A4, personalizado",
        "Capas: couro sintético, PU, rígida",
        "Páginas: 200 a 400",
        "Tipografia: diária, semanal, mensal",
      ],
      options: [
        "Gravação a quente (dourado/prata)",
        "Personalização com logótipo",
        "Elástico marcador",
        "Bolso interior",
      ],
    },
  },
  {
    id: "sacos-personalizados",
    name: "Sacos Personalizados",
    category: "Packaging",
    image: "/products/sacos.png",
    imageAlt: "Saco de papel kraft personalizado em pé com pegas elegantes",
    description: "Kraft ou Couché, várias dimensões.",
    href: "/#orcamento",
    details: {
      longDescription:
        "Sacos de papel personalizados em kraft ou couché, disponíveis em várias dimensões e acabamentos. Soluções de embalagem que valorizam a sua marca no ponto de venda.",
      specs: [
        "Materiais: kraft pardo, couché brilhante/mate",
        "Gramagens: 120g a 250g",
        "Formatos: pequeno, médio, grande",
        "Pegas: cordão, fita, alça plana",
      ],
      options: [
        "Impressão a 1 ou 2 cores",
        "Fundo reforçado",
        "Acabamento verniz",
        "Personalização total",
      ],
    },
  },
  {
    id: "tshirts-polos",
    name: "T-shirts e Polos",
    category: "Têxtil",
    image: "/products/tshirts.png",
    imageAlt: "T-shirts e polos de algodão em tons neutros dobrados e empilhados",
    description: "Timbragem e estampagem duradouras.",
    href: "/#orcamento",
    details: {
      longDescription:
        "T-shirts e polos de algodão com timbragem e estampagem duradouras. Disponíveis em várias cores e tamanhos, ideais para uniformes de equipa, eventos e brindes corporativos.",
      specs: [
        "Material: 100% algodão penteado",
        "Gramagem: 160g a 220g",
        "Tamanhos: S a XXL",
        "Cores: vasto catálogo",
      ],
      options: [
        "Timbragem (clara/escura)",
        "Estampagem por sublimação",
        "Bordado",
        "Personalização com nome individual",
      ],
    },
  },
  {
    id: "canecas-garrafas",
    name: "Canecas e Garrafas",
    category: "Brindes",
    image: "/products/canecas.png",
    imageAlt: "Caneca de cerâmica e garrafa térmica em tons neutros",
    description: "Sublimação de alta qualidade.",
    href: "/#orcamento",
    details: {
      longDescription:
        "Canecas e garrafas térmicas com sublimação de alta qualidade. Disponíveis em cerâmica, aço inoxidável e outros materiais, ideais para brindes corporativos e campanhas promocionais.",
      specs: [
        "Materiais: cerâmica, aço inoxidável, plástico",
        "Capacidades: 300ml a 750ml",
        "Acabamentos: mate, brilhante, soft-touch",
        "Cores base: branco, preto, cores",
      ],
      options: [
        "Sublimação a cores",
        "Personalização total",
        "Embalagem individual",
        "Caixa de oferta",
      ],
    },
  },
  {
    id: "rollups-banners",
    name: "Roll-ups e Banners",
    category: "Comunicação Visual",
    image: "/products/rollups.png",
    imageAlt: "Roll-up banner e banner de vinil enrolados em pé",
    description: "Estruturas robustas, impressão de grande formato.",
    href: "/#orcamento",
    details: {
      longDescription:
        "Roll-ups e banners com estruturas robustas e impressão de grande formato. Soluções portáteis de comunicação visual ideais para eventos, feiras, conferências e espaços comerciais.",
      specs: [
        "Formatos: 85×200cm, 100×200cm, personalizado",
        "Material: lona 440g/m²",
        "Estrutura: alumínio reforçado",
        "Bolsa de transporte incluída",
      ],
      options: [
        "Impressão a cores de alta resolução",
        "Acabamento mate anti-reflexo",
        "Estrutura dupla face",
        "Spot de iluminação opcional",
      ],
    },
  },
];

/** Categorias únicas (para futuros filtros) */
export const productCategories = Array.from(
  new Set(products.map((p) => p.category))
);
