/**
 * Configuração do Hero RAQUIA GRÁFICA — Carrossel de slides.
 *
 * Cada slide tem: eyebrow, headline (2 linhas), subtitle, imagem.
 * Conteúdo editável — pronto para CMS futuro.
 */

export interface HeroSlide {
  /** Label editorial pequena */
  eyebrow: string;
  /** Linha principal da headline */
  line1: string;
  /** Linha de destaque (itálico serif com gradiente) */
  line2: string;
  /** Subtítulo descritivo */
  subtitle: string;
  /** Caminho da imagem */
  image: string;
  /** Alt descritivo (acessibilidade) */
  imageAlt: string;
  /** Etiqueta flutuante (legenda abaixo da imagem) */
  caption: string;
}

export const heroSlides: HeroSlide[] = [
  {
    eyebrow: "Gráfica Premium · Angola",
    line1: "Damos forma",
    line2: "às suas ideias.",
    subtitle:
      "Impressão gráfica, comunicação visual e soluções personalizadas para empresas e particulares.",
    image: "/hero/hero-main.png",
    imageAlt:
      "Materiais gráficos premium produzidos pela RAQUIA GRÁFICA — cartões de visita, embalagens e catálogos sobre fundo off-white com iluminação de estúdio",
    caption: "Projectos executados com precisão",
  },
  {
    eyebrow: "Da identidade à impressão",
    line1: "Transformamos ideias",
    line2: "em materiais.",
    subtitle:
      "Catálogos, revistas e brochuras com acabamento editorial e qualidade fotográfica em cada página.",
    image: "/hero/hero-slide-2.png",
    imageAlt:
      "Catálogos e revistas com design editorial premium dispostos sobre fundo off-white com iluminação de estúdio",
    caption: "Acabamento editorial de excelência",
  },
  {
    eyebrow: "Imprimimos ideias · Materializamos marcas",
    line1: "Brindes e embalagens",
    line2: "que valorizam marcas.",
    subtitle:
      "Soluções personalizadas de packaging e brindes corporativos que elevam a perceção da sua marca.",
    image: "/hero/hero-slide-3.png",
    imageAlt:
      "Brindes corporativos e embalagens premium — caneca, caixa de oferta, sacola e caderno personalizados sobre fundo off-white",
    caption: "Soluções personalizadas premium",
  },
  {
    eyebrow: "Timbragem & Estampagem",
    line1: "Estampamos",
    line2: "a sua identidade.",
    subtitle:
      "Timbragem e estampagem de camisolas e têxteis com a sua marca, nome ou símbolo — qualidade duradoura em cada peça.",
    image: "/hero/hero-slide-4.png",
    imageAlt:
      "Camisolas estampadas em cabide — uma branca com o texto CLAUDINO CESAR e uma preta com o símbolo da RAQUIA GRÁFICA, sobre fundo off-white",
    caption: "Estamparia têxtil personalizada",
  },
  {
    eyebrow: "Comunicação Visual · Grande Formato",
    line1: "Grande formato",
    line2: "com grande impacto.",
    subtitle:
      "Banners, placas, acrílicos e sinalética de grande formato com acabamentos profissionais para qualquer espaço.",
    image: "/hero/hero-slide-5.png",
    imageAlt:
      "Materiais de comunicação visual de grande formato — rolos de banner, placas acrílicas e cavaletes sobre fundo off-white",
    caption: "Sinalética e grande formato",
  },
];

export interface TrustIndicator {
  /** Símbolo geométrico (carácter unicode) */
  symbol: string;
  /** Texto do benefício */
  label: string;
}

export const trustIndicators: TrustIndicator[] = [
  { symbol: "◆", label: "Qualidade profissional" },
  { symbol: "◷", label: "Prazos cumpridos" },
  { symbol: "▣", label: "Soluções personalizadas" },
];
