/**
 * Configuração central do site RAQUIA GRÁFICA.
 * NUNCA espalhar contactos/telefones directamente pelo código.
 * ⚠️ WHATSAPP_NUMBER é um placeholder até configuração final.
 */

export const siteConfig = {
  name: "RAQUIA GRÁFICA",
  shortName: "Raquia",
  tagline: "Impressão & Comunicação Visual Premium",
  description: "Gráfica profissional especializada em impressão, comunicação visual, materiais corporativos, brindes, embalagens e soluções personalizadas em Angola.",
  locale: "pt-AO",
  country: "Angola",
  city: "Luanda",
  whatsapp: "244900000000",
  whatsappDisplay: "+244 900 000 000",
  phone: "+244 900 000 000",
  phoneDisplay: "+244 900 000 000",
  email: "geral@raquiagrafica.ao",
  address: {
    street: "Rua Comercial, Edifício Raquia",
    zone: "Maianga",
    city: "Luanda",
    province: "Luanda",
    country: "Angola",
    full: "Rua Comercial, Edifício Raquia, Maianga, Luanda, Angola",
    coordinates: { lat: -8.8147, lng: 13.2302 },
    mapsUrl: "https://maps.google.com/?q=Luanda+Angola",
  },
  hours: [
    { day: "Segunda a Sexta", time: "08h00 — 18h00" },
    { day: "Sábado", time: "09h00 — 13h00" },
    { day: "Domingo", time: "Fechado" },
  ],
  social: {
    instagram: "https://instagram.com/raquiagrafica",
    facebook: "https://facebook.com/raquiagrafica",
    linkedin: "https://linkedin.com/company/raquiagrafica",
  },
} as const;

export type SiteConfig = typeof siteConfig;

export interface ContactItem {
  id: string;
  icon: string;
  label: string;
  value: string;
  href: string;
  external?: boolean;
}

export const contactItems: ContactItem[] = [
  { id: "phone", icon: "Phone", label: "Telefone", value: siteConfig.phoneDisplay, href: `tel:${siteConfig.phone.replace(/\s/g, "")}` },
  { id: "whatsapp", icon: "MessageCircle", label: "WhatsApp", value: siteConfig.whatsappDisplay, href: `https://wa.me/${siteConfig.whatsapp}`, external: true },
  { id: "email", icon: "Mail", label: "Email", value: siteConfig.email, href: `mailto:${siteConfig.email}` },
  { id: "address", icon: "MapPin", label: "Localização", value: siteConfig.address.full, href: siteConfig.address.mapsUrl, external: true },
];
