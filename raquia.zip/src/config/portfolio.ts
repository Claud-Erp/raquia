/**
 * Configuração do portfólio RAQUIA GRÁFICA.
 *
 * Conteúdo editável — pronto para ligação futura a CMS/backend.
 * Cada trabalho tem: id, título, categoria, imagem, descrição.
 *
 * Trabalhos orientados ao mercado angolano (empresas reais Angola).
 */

export type PortfolioCategory =
  | "Branding"
  | "Impressão"
  | "Embalagens"
  | "Comunicação Visual"
  | "Brindes"
  | "Corporativo";

export interface PortfolioItem {
  /** Identificador único (slug) */
  id: string;
  /** Título do trabalho */
  title: string;
  /** Categoria (para filtros) */
  category: PortfolioCategory;
  /** Cliente (opcional) */
  client?: string;
  /** Caminho da imagem */
  image: string;
  /** Alt descritivo (acessibilidade) */
  imageAlt: string;
  /** Descrição curta */
  description: string;
}

/** Categorias para os filtros (inclui "Todos") */
export const portfolioFilters: Array<{ label: string; value: "Todos" | PortfolioCategory }> = [
  { label: "Todos", value: "Todos" },
  { label: "Branding", value: "Branding" },
  { label: "Impressão", value: "Impressão" },
  { label: "Embalagens", value: "Embalagens" },
  { label: "Comunicação Visual", value: "Comunicação Visual" },
  { label: "Brindes", value: "Brindes" },
  { label: "Corporativo", value: "Corporativo" },
];

export const portfolioItems: PortfolioItem[] = [
  // ===== Branding =====
  {
    id: "branding-identidade-bancaria",
    title: "Identidade Bancária",
    category: "Branding",
    client: "Instituição Financeira · Luanda",
    image: "/portfolio/branding-1.png",
    imageAlt:
      "Identidade visual de banco angolano: cartões, papel timbrado e pasta de marca sobre fundo off-white com padrão geométrico africano subtil",
    description:
      "Sistema de identidade visual completo para instituição bancária, com manual de normas e papelaria executiva.",
  },
  {
    id: "branding-papelaria-telecom",
    title: "Papelaria de Telecomunicações",
    category: "Branding",
    client: "Operadora Telecom · Angola",
    image: "/portfolio/corporativo-1.png",
    imageAlt:
      "Pasta de apresentação rígida preta com cartões de visita e papel timbrado de operadora de telecomunicações sobre fundo off-white",
    description:
      "Kit de papelaria corporativa para operadora de telecomunicações, com pasta executiva e cartões premium.",
  },

  // ===== Impressão =====
  {
    id: "impressao-convites-casamento",
    title: "Convites de Casamento",
    category: "Impressão",
    client: "Evento de Elite · Luanda",
    image: "/portfolio/impressao-2.png",
    imageAlt:
      "Conjunto de convites de casamento de luxo com embossing e foil dourado, padrão têxtil angolano subtil na borda, sobre fundo off-white",
    description:
      "Convites de casamento de alto padrão com relevo seco, foil dourado e padrão têxtil tradicional angolano.",
  },
  {
    id: "impressao-catalogo-moda",
    title: "Catálogo de Moda",
    category: "Impressão",
    client: "Marca de Moda Angolana",
    image: "/portfolio/impressao-3.png",
    imageAlt:
      "Catálogo de moda aberto com layout editorial elegante e fotografia de alta qualidade sobre fundo off-white",
    description:
      "Catálogo de moda para marca angolana com encadernação lombada quadrada e impressão fotográfica de alta resolução.",
  },
  {
    id: "impressao-cartoes-premium",
    title: "Cartões Premium",
    category: "Impressão",
    client: "Cliente Particular · Luanda",
    image: "/products/cartoes-visita.png",
    imageAlt:
      "Cartões de visita em papel texturizado preto e off-white dispostos em leque",
    description:
      "Cartões de visita em papel 600g com acabamento soft-touch e hot stamping para profissional liberal em Luanda.",
  },

  // ===== Embalagens =====
  {
    id: "embalagens-caixa-luxo",
    title: "Caixa de Oferta Premium",
    category: "Embalagens",
    client: "Marca de Luxo · Angola",
    image: "/portfolio/embalagens-1.png",
    imageAlt:
      "Caixas rígidas preta e kraft com fita, sacola personalizada e rótulos de marca de luxo angolana sobre fundo off-white",
    description:
      "Caixas rígidas com acabamento premium e rótulos personalizados para marca de luxo no mercado angolano.",
  },
  {
    id: "embalagens-cosmetica-beleza",
    title: "Embalagem de Beleza",
    category: "Embalagens",
    client: "Marca de Cosmética Angolana",
    image: "/portfolio/embalagens-2.png",
    imageAlt:
      "Embalagens de cosmética minimalistas em preto e branco com padrão geométrico africano subtil sobre fundo off-white",
    description:
      "Rótulos e embalagens para linha de cosmética angolana com design minimalista e padrão inspirado em tecidos tradicionais.",
  },

  // ===== Comunicação Visual =====
  {
    id: "comunicacao-sinaletica-corporativa",
    title: "Sinalética Corporativa",
    category: "Comunicação Visual",
    client: "Edifício Corporativo · Luanda",
    image: "/portfolio/comunicacao-1.png",
    imageAlt:
      "Placas de sinalética em acrílico fosco montadas em parede off-white com padrão geométrico africano subtil, para edifício corporativo em Luanda",
    description:
      "Sinalética interior em acrílico para edifício corporativo em Luanda, com acabamento profissional e design institucional.",
  },
  {
    id: "comunicacao-rollup-feira",
    title: "Roll-up de Feira",
    category: "Comunicação Visual",
    client: "Feira Internacional de Luanda",
    image: "/products/rollups.png",
    imageAlt:
      "Roll-up banner e banner de vinil enrolados em pé sobre fundo off-white para feira internacional",
    description:
      "Roll-ups e banners para a Feira Internacional de Luanda, com impressão de grande formato e estruturas robustas.",
  },

  // ===== Brindes =====
  {
    id: "brindes-kit-petroleo",
    title: "Kit Corporativo Petrolífero",
    category: "Brindes",
    client: "Empresa Petrolífera · Angola",
    image: "/portfolio/brindes-1.png",
    imageAlt:
      "Kit de brindes corporativos para empresa petrolífera angolana: caneca, caderno de couro, caneta e saco de pano sobre fundo off-white",
    description:
      "Kit de brindes corporativos personalizados para empresa do sector petrolífero, com acabamentos executivos.",
  },
  {
    id: "brindes-canecas-campanha",
    title: "Canecas Promocionais",
    category: "Brindes",
    client: "Campanha Comercial · Luanda",
    image: "/products/canecas.png",
    imageAlt:
      "Caneca de cerâmica e garrafa térmica em tons neutros sobre fundo off-white para campanha comercial",
    description:
      "Canecas e garrafas com sublimação de alta qualidade para campanha comercial promocional em Luanda.",
  },

  // ===== Corporativo =====
  {
    id: "corporativo-agenda-banco",
    title: "Agenda Executiva Bancária",
    category: "Corporativo",
    client: "Banco Comercial · Angola",
    image: "/products/agendas.png",
    imageAlt:
      "Agenda de couro com capa gravada e caneta sobre fundo off-white para banco comercial angolano",
    description:
      "Agendas executivas em couro com gravação a quente, oferta corporativa de banco comercial angolano.",
  },
  {
    id: "corporativo-uniformes-supermercado",
    title: "Uniformes de Supermercado",
    category: "Corporativo",
    client: "Rede de Supermercados · Angola",
    image: "/hero/hero-slide-4.png",
    imageAlt:
      "Duas camisolas estampadas separadas — uma branca com texto e uma preta com símbolo personalizado para uniformes de supermercado",
    description:
      "Timbragem de t-shirts e polos para uniformes de equipa de rede de supermercados angolana, com a marca do cliente.",
  },
];
