/**
 * Helper para construir URL de WhatsApp (wa.me) com mensagem pré-preenchida.
 * O número vem SEMPRE de siteConfig — nunca hardcoded nos componentes.
 */
import { siteConfig } from "@/config/site";

export function buildWhatsAppUrl(message?: string): string {
  const base = `https://wa.me/${siteConfig.whatsapp}`;
  if (!message) return base;
  return `${base}?text=${encodeURIComponent(message)}`;
}

export const defaultWhatsAppMessage =
  "Olá! Vim pelo site da RAQUIA GRÁFICA e gostaria de solicitar um orçamento.";
