import { z } from "zod";
import { fileUploadConfig } from "@/config/quote";

const phoneRegex = /^(\+244)?\s?9\d{8}$/;

const fileSchema = z
  .instanceof(File, { message: "Ficheiro inválido." })
  .refine((file) => file.size <= fileUploadConfig.maxSizeBytes, `O ficheiro excede o tamanho máximo de ${fileUploadConfig.maxSizeLabel}.`)
  .refine((file) => { const ext = "." + file.name.split(".").pop()?.toLowerCase(); return fileUploadConfig.allowedTypes.includes(file.type) || fileUploadConfig.allowedExtensions.includes(ext); }, "Tipo de ficheiro não permitido. Use PDF, JPG, PNG ou WebP.")
  .nullable()
  .optional();

export const quoteFormSchema = z.object({
  nome: z.string().min(2, { message: "Indique o seu nome (mínimo 2 caracteres)." }).max(100, { message: "Nome demasiado longo." }),
  empresa: z.string().max(100, { message: "Nome da empresa demasiado longo." }).optional().or(z.literal("")),
  telefone: z.string().min(1, { message: "O telefone é obrigatório." }).regex(phoneRegex, { message: "Telefone inválido. Use o formato +244 9XXXXXXXX ou 9XXXXXXXX." }),
  email: z.string().min(1, { message: "O email é obrigatório." }).email({ message: "Email inválido. Verifique o formato." }),
  tipoServico: z.string().min(1, { message: "Seleccione um tipo de serviço." }),
  produto: z.string().min(1, { message: "Seleccione um produto." }),
  quantidade: z.coerce.number({ message: "Indique uma quantidade válida." }).int({ message: "A quantidade deve ser um número inteiro." }).min(1, { message: "A quantidade mínima é 1." }).max(100000, { message: "Quantidade demasiado elevada. Contacte-nos directamente." }),
  prazo: z.string().min(1, { message: "Seleccione um prazo." }),
  descricao: z.string().min(10, { message: "Descreva o seu projecto (mínimo 10 caracteres)." }).max(2000, { message: "Descrição demasiado longa (máximo 2000 caracteres)." }),
  ficheiro: fileSchema,
  observacoes: z.string().max(1000, { message: "Observações demasiado longas." }).optional().or(z.literal("")),
  consentimento: z.boolean().refine((v) => v === true, { message: "Deve aceitar a política de privacidade para continuar." }),
});

export type QuoteFormValues = z.infer<typeof quoteFormSchema>;
