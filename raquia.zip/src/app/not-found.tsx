import Link from "next/link";
import { Container, RaquiaButton } from "@/components/raquia";
import { ArrowRight, Home } from "lucide-react";

export const metadata = {
  title: "Página não encontrada — 404",
  description: "A página que procura não existe ou foi movida. Volte à página inicial da RAQUIA GRÁFICA.",
  robots: { index: false, follow: true },
};

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Container variant="narrow" className="flex flex-1 flex-col items-center justify-center py-20 text-center">
        <span className="font-sans text-[0.7rem] font-medium uppercase tracking-[0.22em] text-muted-foreground">
          Erro 404
        </span>
        <h1 className="mt-6 font-serif text-6xl font-semibold tracking-[-0.03em] text-ink sm:text-8xl">
          Página não encontrada
        </h1>
        <p className="mt-6 max-w-md text-base leading-relaxed text-muted-foreground sm:text-lg">
          A página que procura não existe ou foi movida. Volte à página inicial
          ou explore os nossos serviços de impressão premium.
        </p>
        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <RaquiaButton asChild variant="primary" size="lg">
            <Link href="/">
              <Home className="size-4" />
              Voltar ao início
            </Link>
          </RaquiaButton>
          <RaquiaButton asChild variant="outline" size="lg">
            <Link href="/#servicos">
              Ver serviços
              <ArrowRight className="size-4" />
            </Link>
          </RaquiaButton>
        </div>
      </Container>
    </div>
  );
}
