import type { MetadataRoute } from "next";
import { siteUrl } from "@/config/seo";

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();
  const sections = ["inicio","servicos","produtos","sobre","portfolio","orcamento","contactos"];
  const routes = sections.map((section) => ({ url: `${siteUrl}/#${section}`, lastModified, changeFrequency: "monthly" as const, priority: section === "inicio" ? 1.0 : 0.8 }));
  const legalPages = [{ path: "/politica-de-privacidade", priority: 0.3 },{ path: "/termos-e-condicoes", priority: 0.3 }].map((p) => ({ url: `${siteUrl}${p.path}`, lastModified, changeFrequency: "yearly" as const, priority: p.priority }));
  const pdfs = [{ path: "/servicos-raquia-grafica.pdf", priority: 0.6 },{ path: "/produtos-raquia-grafica.pdf", priority: 0.6 }].map((p) => ({ url: `${siteUrl}${p.path}`, lastModified, changeFrequency: "monthly" as const, priority: p.priority }));
  return [{ url: siteUrl, lastModified, changeFrequency: "weekly" as const, priority: 1.0 }, ...routes, ...legalPages, ...pdfs];
}
