import { Header, WhatsAppFloat, Footer } from "@/components/layout";
import {
  Hero,
  Services,
  Products,
  About,
  Portfolio,
  QuoteCTA,
  Contact,
} from "@/components/sections";

/**
 * Home RAQUIA GRÁFICA.
 *
 * Estrutura completa da landing page:
 * - Header (sticky)
 * - Hero (#inicio)
 * - Services (#servicos)
 * - Products (#produtos)
 * - About (#sobre)
 * - Portfolio (#portfolio)
 * - QuoteCTA (#orcamento)
 * - Contact (#contactos)
 * - Footer (premium multi-coluna)
 * - WhatsAppFloat (botão flutuante)
 */
export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1">
        {/* HERO — secção #inicio */}
        <Hero />

        {/* SERVIÇOS — secção #servicos */}
        <Services />

        {/* PRODUTOS — secção #produtos */}
        <Products />

        {/* SOBRE — secção #sobre */}
        <About />

        {/* PORTFÓLIO — secção #portfolio */}
        <Portfolio />

        {/* ORÇAMENTO — secção #orcamento */}
        <QuoteCTA />

        {/* CONTACTOS — secção #contactos */}
        <Contact />
      </main>

      {/* Footer premium multi-coluna */}
      <Footer />

      {/* Botão flutuante de WhatsApp (visível após scroll > 400px) */}
      <WhatsAppFloat />
    </div>
  );
}
