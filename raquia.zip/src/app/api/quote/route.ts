import { NextRequest, NextResponse } from "next/server";
import { quoteFormSchema } from "@/lib/quote-schema";
import { fileUploadConfig } from "@/config/quote";

export async function POST(request: NextRequest) {
  try {
    const ip = request.headers.get("x-forwarded-for") || "unknown";
    const contentType = request.headers.get("content-type") || "";

    if (!contentType.includes("application/json")) {
      return NextResponse.json({ error: "Content-Type deve ser application/json" }, { status: 415 });
    }

    const parsedBody = await request.json();
    const result = quoteFormSchema.safeParse(parsedBody);

    if (!result.success) {
      const errors = result.error.flatten().fieldErrors;
      return NextResponse.json({ success: false, error: "Dados inválidos", details: errors }, { status: 400 });
    }

    const data = result.data;

    if (data.ficheiro) {
      const file = data.ficheiro;
      if (file.size > fileUploadConfig.maxSizeBytes) {
        return NextResponse.json({ success: false, error: `Ficheiro excede o tamanho máximo de ${fileUploadConfig.maxSizeLabel}` }, { status: 400 });
      }
    }

    console.log("[Quote] Pedido recebido:", { nome: data.nome, email: data.email, telefone: data.telefone, tipoServico: data.tipoServico, produto: data.produto, quantidade: data.quantidade, timestamp: new Date().toISOString(), ip });

    return NextResponse.json({ success: true, message: "Pedido de orçamento recebido com sucesso" }, { status: 200 });
  } catch (error) {
    console.error("[Quote] Erro no processamento:", error);
    return NextResponse.json({ success: false, error: "Erro interno do servidor. Tente novamente mais tarde." }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({ error: "Método não permitido. Use POST." }, { status: 405 });
}
