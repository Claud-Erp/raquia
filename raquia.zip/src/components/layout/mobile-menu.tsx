"use client";

import * as React from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
  SheetDescription,
  SheetClose,
} from "@/components/ui/sheet";
import { navItems } from "@/config/navigation";
import { siteConfig } from "@/config/site";
import { buildWhatsAppUrl, defaultWhatsAppMessage } from "@/lib/whatsapp";
import { Logo, RaquiaButton, Eyebrow } from "@/components/raquia";
import { ArrowRight, Menu, Phone, Mail, MapPin } from "lucide-react";

interface MobileMenuProps {
  activeSection?: string | null;
}

/**
 * MobileMenu RAQUIA GRÁFICA — menu hamburger premium.
 *
 * Características:
 * - Trigger hamburger animado (3 linhas → X ao abrir)
 * - Sheet lateral direito (slide-in suave)
 * - Itens com animação stagger (fade-up em cascata)
 * - Active state destacado
 * - CTA Orçamento destacado no topo
 * - Bloco de contactos no fundo
 * - Fecha ao clicar num link
 * - Acessível (focus trap via Radix, aria-labels)
 * - Bloqueia scroll do body quando aberto
 */
export function MobileMenu({ activeSection }: MobileMenuProps) {
  const [open, setOpen] = React.useState(false);

  // Fecha o menu ao pressionar Escape (Radix já faz, mas garantimos)
  // e bloqueia scroll do body quando aberto
  React.useEffect(() => {
    if (open) {
      const original = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = original;
      };
    }
  }, [open]);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button
          type="button"
          aria-label="Abrir menu de navegação"
          aria-expanded={open}
          aria-controls="mobile-menu-content"
          className={cn(
            "inline-flex size-10 items-center justify-center rounded-sm",
            "text-ink transition-colors hover:bg-accent",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          )}
        >
          <HamburgerIcon open={open} />
        </button>
      </SheetTrigger>

      <SheetContent
        id="mobile-menu-content"
        side="right"
        className={cn(
          "w-full sm:max-w-sm p-0 gap-0",
          "bg-background border-l border-border"
        )}
      >
        <SheetTitle className="sr-only">Menu de navegação RAQUIA GRÁFICA</SheetTitle>
        <SheetDescription className="sr-only">
          Navegue pelas secções do site, solicite um orçamento ou contacte-nos
          directamente.
        </SheetDescription>

        {/* Cabeçalho do menu */}
        <div className="flex h-20 items-center justify-between border-b border-border px-6">
          <Logo size="sm" />
          <SheetClose asChild>
            <button
              type="button"
              aria-label="Fechar menu"
              className="inline-flex size-10 items-center justify-center rounded-sm text-ink transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <svg
                width="18"
                height="18"
                viewBox="0 0 18 18"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
              >
                <path
                  d="M1 1L17 17M17 1L1 17"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
              </svg>
            </button>
          </SheetClose>
        </div>

        {/* CTA Orçamento destacado */}
        <div className="border-b border-border bg-off-white px-6 py-6">
          <SheetClose asChild>
            <RaquiaButton asChild variant="primary" size="lg" className="w-full">
              <Link href="/#orcamento">
                Solicitar Orçamento
                <ArrowRight className="size-4" />
              </Link>
            </RaquiaButton>
          </SheetClose>
        </div>

        {/* Lista de navegação */}
        <nav
          className="flex-1 overflow-y-auto px-6 py-6"
          aria-label="Navegação mobile"
        >
          <Eyebrow withLine className="mb-5">
            Menu
          </Eyebrow>
          <ul className="space-y-1">
            {navItems.map((item, i) => {
              const isActive = activeSection === item.section;
              return (
                <li
                  key={item.section}
                  style={{
                    animation: open
                      ? `mobile-nav-in 0.4s ease-out ${0.05 + i * 0.05}s both`
                      : undefined,
                  }}
                >
                  <SheetClose asChild>
                    <Link
                      href={item.href}
                      className={cn(
                        "group flex items-center justify-between rounded-sm px-4 py-3.5",
                        "font-serif text-2xl transition-all duration-200",
                        isActive
                          ? "bg-ink text-paper"
                          : "text-ink hover:bg-accent"
                      )}
                      aria-current={isActive ? "page" : undefined}
                    >
                      <span className="flex items-baseline gap-3">
                        <span
                          className={cn(
                            "font-sans text-[0.65rem] tracking-[0.2em]",
                            isActive ? "text-white/50" : "text-muted-foreground"
                          )}
                        >
                          0{i + 1}
                        </span>
                        {item.label}
                      </span>
                      <ArrowRight
                        className={cn(
                          "size-5 transition-transform duration-300",
                          "group-hover:translate-x-1",
                          isActive ? "text-paper" : "text-muted-foreground"
                        )}
                      />
                    </Link>
                  </SheetClose>
                </li>
              );
            })}
          </ul>

          {/* Separador */}
          <div className="my-6 h-px w-full bg-border" />

          {/* Contactos rápidos */}
          <div className="space-y-4">
            <Eyebrow withLine>Contactos</Eyebrow>
            <a
              href={buildWhatsAppUrl(defaultWhatsAppMessage)}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-3 text-sm text-ink hover:text-muted-foreground transition-colors"
            >
              <span className="flex size-9 items-center justify-center rounded-sm bg-ink text-paper">
                <Phone className="size-4" />
              </span>
              <span>
                <span className="block text-[0.65rem] uppercase tracking-[0.18em] text-muted-foreground">
                  WhatsApp
                </span>
                {siteConfig.whatsappDisplay}
              </span>
            </a>
            <a
              href={`mailto:${siteConfig.email}`}
              className="group flex items-center gap-3 text-sm text-ink hover:text-muted-foreground transition-colors"
            >
              <span className="flex size-9 items-center justify-center rounded-sm bg-ink text-paper">
                <Mail className="size-4" />
              </span>
              <span>
                <span className="block text-[0.65rem] uppercase tracking-[0.18em] text-muted-foreground">
                  Email
                </span>
                {siteConfig.email}
              </span>
            </a>
            <div className="flex items-center gap-3 text-sm text-ink">
              <span className="flex size-9 items-center justify-center rounded-sm bg-ink text-paper">
                <MapPin className="size-4" />
              </span>
              <span>
                <span className="block text-[0.65rem] uppercase tracking-[0.18em] text-muted-foreground">
                  Localização
                </span>
                {siteConfig.address}
              </span>
            </div>
          </div>
        </nav>

        {/* Rodapé do menu */}
        <div className="border-t border-border bg-off-white px-6 py-5">
          <p className="text-[0.65rem] uppercase tracking-[0.18em] text-muted-foreground">
            © {new Date().getFullYear()} {siteConfig.name}
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}

/**
 * Ícone hamburger animado — 3 linhas → X.
 */
function HamburgerIcon({ open }: { open: boolean }) {
  return (
    <div className="relative flex h-4 w-5 flex-col justify-between">
      <span
        className={cn(
          "block h-px w-full bg-current transition-all duration-300",
          open && "translate-y-[7px] rotate-45"
        )}
      />
      <span
        className={cn(
          "block h-px w-full bg-current transition-all duration-300",
          open && "opacity-0"
        )}
      />
      <span
        className={cn(
          "block h-px w-full bg-current transition-all duration-300",
          open && "-translate-y-[7px] -rotate-45"
        )}
      />
    </div>
  );
}
