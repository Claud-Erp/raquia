/**
 * Barrel export dos componentes de layout.
 */
export { Header } from "./header";
export { MobileMenu } from "./mobile-menu";
export { Footer } from "./footer";
export { WhatsAppFloat } from "./whatsapp-float";
