import Link from "next/link";
import { Container, Logo, RaquiaButton } from "@/components/raquia";
import { siteConfig } from "@/config/site";
import { footerNav, footerServices, footerLegal, footerCatalogs, footerDescription, footerCopyrightYear } from "@/config/footer";
import { buildWhatsAppUrl, defaultWhatsAppMessage } from "@/lib/whatsapp";
import { Instagram, Facebook, Linkedin, Phone, Mail, MapPin, ArrowUpRight, type LucideIcon } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-ink text-paper" role="contentinfo">
      <Container variant="wide" className="py-16 lg:py-20">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-4">
            <Logo size="md" variant="light" />
            <p className="mt-6 max-w-xs text-sm leading-relaxed text-white/60">{footerDescription}</p>
            <div className="mt-6"><RaquiaButton asChild variant="light" size="default"><a href={buildWhatsAppUrl(defaultWhatsAppMessage)} target="_blank" rel="noopener noreferrer">Solicitar Orçamento<ArrowUpRight className="size-4" /></a></RaquiaButton></div>
          </div>
          <div className="lg:col-span-2">
            <FooterColumnTitle>Navegação</FooterColumnTitle>
            <nav aria-label="Navegação do rodapé"><ul className="space-y-2.5">{footerNav.map((link) => (<li key={link.label}><Link href={link.href} className="link-underline text-sm text-white/70 hover:text-paper">{link.label}</Link></li>))}</ul></nav>
            <FooterColumnTitle className="mt-8">Catálogos</FooterColumnTitle>
            <ul className="space-y-2.5">{footerCatalogs.map((link) => (<li key={link.label}><a href={link.href} target={link.external ? "_blank" : undefined} rel={link.external ? "noopener noreferrer" : undefined} className="link-underline inline-flex items-center gap-1 text-sm text-white/70 hover:text-paper">{link.label}<ArrowUpRight className="size-3.5" /></a></li>))}</ul>
          </div>
          <div className="lg:col-span-3">
            <FooterColumnTitle>Serviços</FooterColumnTitle>
            <nav aria-label="Serviços"><ul className="space-y-2.5">{footerServices.map((link) => (<li key={link.label}><Link href={link.href} className="link-underline text-sm text-white/70 hover:text-paper">{link.label}</Link></li>))}</ul></nav>
          </div>
          <div className="lg:col-span-3">
            <FooterColumnTitle>Contactos</FooterColumnTitle>
            <address className="not-italic space-y-3">
              <FooterContactRow icon={Phone} label={siteConfig.phoneDisplay} href={`tel:${siteConfig.phone.replace(/\s/g, "")}`} />
              <FooterContactRow icon={Mail} label={siteConfig.email} href={`mailto:${siteConfig.email}`} />
              <FooterContactRow icon={MapPin} label={siteConfig.address.full} href={siteConfig.address.mapsUrl} external />
            </address>
            <div className="mt-6"><p className="font-sans text-[0.65rem] font-medium uppercase tracking-[0.22em] text-white/50">Siga-nos</p><div className="mt-3 flex items-center gap-3"><SocialLink href={siteConfig.social.instagram} icon={Instagram} label="Instagram" /><SocialLink href={siteConfig.social.facebook} icon={Facebook} label="Facebook" /><SocialLink href={siteConfig.social.linkedin} icon={Linkedin} label="LinkedIn" /></div></div>
          </div>
        </div>
      </Container>
      <div className="border-t border-white/10"><Container variant="wide"><div className="flex flex-col items-center justify-between gap-4 py-6 sm:flex-row"><p className="text-xs text-white/50">© {footerCopyrightYear} {siteConfig.name} · Todos os direitos reservados</p><nav aria-label="Links legais" className="flex items-center gap-6">{footerLegal.map((link) => (<Link key={link.label} href={link.href} className="link-underline text-xs text-white/50 hover:text-paper">{link.label}</Link>))}</nav></div></Container></div>
    </footer>
  );
}

function FooterColumnTitle({ children, className }: { children: React.ReactNode; className?: string }) {
  return <h3 className={`font-sans text-[0.7rem] font-medium uppercase tracking-[0.22em] text-white/50 ${className ?? ""}`}>{children}</h3>;
}

function FooterContactRow({ icon: Icon, label, href, external }: { icon: LucideIcon; label: string; href: string; external?: boolean }) {
  return <a href={href} {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})} className="group flex items-start gap-2.5 text-sm text-white/70 transition-colors hover:text-paper"><Icon className="mt-0.5 size-4 shrink-0 text-white/50 transition-colors group-hover:text-paper" /><span className="break-words">{label}</span></a>;
}

function SocialLink({ href, icon: Icon, label }: { href: string; icon: LucideIcon; label: string }) {
  return <a href={href} target="_blank" rel="noopener noreferrer" aria-label={label} className="inline-flex size-10 items-center justify-center rounded-full border border-white/20 bg-white/5 text-white/70 transition-all hover:border-paper hover:bg-paper hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-paper focus-visible:ring-offset-2 focus-visible:ring-offset-ink"><Icon className="size-5" /></a>;
}
