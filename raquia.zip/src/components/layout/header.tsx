"use client";

import * as React from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { navItems } from "@/config/navigation";
import { useScrolled } from "@/hooks/use-scrolled";
import { useActiveSection } from "@/hooks/use-active-section";
import { Logo } from "@/components/raquia";
import { RaquiaButton } from "@/components/raquia";
import { MobileMenu } from "./mobile-menu";
import { ArrowRight } from "lucide-react";

/**
 * Header RAQUIA GRÁFICA — cabeçalho premium sticky.
 *
 * Estrutura: Logo (esq) · Menu central (7 itens) · CTA Orçamento (dir)
 *
 * Comportamentos:
 * - Sticky no topo
 * - Fundo transparente → fundo sólido com backdrop-blur ao scrollar
 * - Borda inferior extremamente discreta (só quando scrollado)
 * - Altura contrai ligeiramente ao scrollar (subtil)
 * - Active state no item da secção visível
 * - Hover com underline animado (link-underline do design system)
 * - Menu mobile via Sheet animado (componente separado)
 * - Focus states acessíveis (teclado)
 */
export function Header() {
  const scrolled = useScrolled(8);
  const active = useActiveSection();

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300 ease-out",
        scrolled
          ? "border-b border-border/60 bg-background/85 backdrop-blur-xl supports-[backdrop-filter]:bg-background/75"
          : "border-b border-transparent bg-background/0"
      )}
      role="banner"
    >
      <div
        className={cn(
          "mx-auto w-full max-w-[80rem] px-5 sm:px-6 lg:px-8 transition-all duration-300",
          scrolled ? "h-16" : "h-20"
        )}
      >
        <div className="flex h-full items-center justify-between gap-4">
          {/* ===================== LOGO ===================== */}
          <Logo
            size={scrolled ? "sm" : "md"}
            className={cn("shrink-0 transition-all", scrolled && "scale-[0.97]")}
          />

          {/* ===================== MENU CENTRAL (desktop) ===================== */}
          <nav
            className="hidden lg:flex items-center gap-1"
            aria-label="Navegação principal"
          >
            {navItems.map((item) => {
              const isActive = active === item.section;
              return (
                <Link
                  key={item.section}
                  href={item.href}
                  className={cn(
                    "link-underline px-3 py-2 text-sm font-medium transition-colors duration-200",
                    isActive
                      ? "text-ink"
                      : "text-muted-foreground hover:text-ink"
                  )}
                  aria-current={isActive ? "page" : undefined}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          {/* ===================== CTA ORÇAMENTO (desktop) + HAMBURGER (mobile) ===================== */}
          <div className="flex items-center gap-3">
            <RaquiaButton
              asChild
              variant="primary"
              size={scrolled ? "sm" : "default"}
              className="hidden sm:inline-flex"
            >
              <Link href="/#orcamento">
                Solicitar Orçamento
                <ArrowRight className="size-4" />
              </Link>
            </RaquiaButton>

            {/* Hamburger — só mobile */}
            <div className="lg:hidden">
              <MobileMenu activeSection={active} />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
