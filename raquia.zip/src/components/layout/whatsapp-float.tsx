"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { buildWhatsAppUrl, defaultWhatsAppMessage } from "@/lib/whatsapp";
import { MessageCircle } from "lucide-react";

export function WhatsAppFloat() {
  const [visible, setVisible] = React.useState(false);
  const [tooltipOpen, setTooltipOpen] = React.useState(false);

  React.useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 400);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <a
      href={buildWhatsAppUrl(defaultWhatsAppMessage)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar connosco no WhatsApp (abre numa nova aba)"
      onMouseEnter={() => setTooltipOpen(true)}
      onMouseLeave={() => setTooltipOpen(false)}
      onFocus={() => setTooltipOpen(true)}
      onBlur={() => setTooltipOpen(false)}
      className={cn(
        "group fixed bottom-5 right-5 z-40 inline-flex size-14 items-center justify-center rounded-full",
        "bg-[#25D366] text-white shadow-[0_8px_24px_-6px_rgba(37,211,102,0.5)]",
        "transition-all duration-300 ease-out",
        "hover:scale-110 hover:shadow-[0_12px_32px_-6px_rgba(37,211,102,0.7)]",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#25D366] focus-visible:ring-offset-2 focus-visible:ring-offset-background",
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
      )}
    >
      <span className={cn("pointer-events-none absolute right-full mr-3 hidden whitespace-nowrap rounded-sm bg-ink px-3 py-2 text-xs font-medium text-paper shadow-lg lg:block", "transition-all duration-200", tooltipOpen ? "translate-x-0 opacity-100" : "translate-x-2 opacity-0")}>Fale connosco</span>
      <span aria-hidden="true" className="absolute inset-0 -z-10 animate-ping rounded-full bg-[#25D366] opacity-30" />
      <MessageCircle className="size-7" />
    </a>
  );
}
