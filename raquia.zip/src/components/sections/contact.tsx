import { Container, Eyebrow, Heading, RaquiaButton } from "@/components/raquia";
import { siteConfig, contactItems } from "@/config/site";
import { buildWhatsAppUrl, defaultWhatsAppMessage } from "@/lib/whatsapp";
import { RevealOnScroll } from "@/components/shared";
import { Phone, MessageCircle, Mail, MapPin, Clock, ArrowUpRight, Instagram, Facebook, Linkedin } from "lucide-react";
import type { LucideIcon } from "lucide-react";

const iconMap: Record<string, LucideIcon> = { Phone, MessageCircle, Mail, MapPin };

export function Contact() {
  return (
    <section id="contactos" aria-label="Contactos da RAQUIA GRÁFICA" className="scroll-mt-20 bg-off-white py-20 lg:py-28">
      <Container variant="wide">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-2 lg:gap-16 xl:gap-20">
          <div>
            <Eyebrow withLine>Contactos</Eyebrow>
            <Heading level="h2" className="mt-6">Estamos <span className="italic font-normal text-gradient-ink">à sua disposição</span></Heading>
            <p className="mt-5 max-w-md text-base leading-relaxed text-muted-foreground sm:text-lg">Contacte-nos pelo canal que preferir. A nossa equipa está pronta para ajudar a transformar as suas ideias em materiais de excelência.</p>
            <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2">
              {contactItems.map((item, i) => {
                const Icon = iconMap[item.icon] || Phone;
                return (
                  <RevealOnScroll key={item.id} animation="fade-up" delay={i * 100}>
                    <a href={item.href} {...(item.external ? { target: "_blank", rel: "noopener noreferrer" } : {})} className="group flex items-start gap-4 border-l border-border pl-4 transition-colors hover:border-ink">
                      <span className="flex size-10 shrink-0 items-center justify-center bg-ink text-paper transition-colors group-hover:bg-ink-soft"><Icon className="size-5" /></span>
                      <div className="min-w-0"><p className="font-sans text-[0.65rem] font-medium uppercase tracking-[0.22em] text-muted-foreground">{item.label}</p><p className="mt-1 text-sm font-medium text-ink break-words">{item.value}</p></div>
                    </a>
                  </RevealOnScroll>
                );
              })}
            </div>
            <div className="mt-10">
              <RaquiaButton asChild variant="primary" size="lg"><a href={buildWhatsAppUrl(defaultWhatsAppMessage)} target="_blank" rel="noopener noreferrer"><MessageCircle className="size-4" />Iniciar conversa no WhatsApp</a></RaquiaButton>
            </div>
            <div className="mt-10">
              <p className="font-sans text-[0.65rem] font-medium uppercase tracking-[0.22em] text-muted-foreground">Siga-nos</p>
              <div className="mt-3 flex items-center gap-3">
                <SocialLink href={siteConfig.social.instagram} icon={Instagram} label="Instagram" />
                <SocialLink href={siteConfig.social.facebook} icon={Facebook} label="Facebook" />
                <SocialLink href={siteConfig.social.linkedin} icon={Linkedin} label="LinkedIn" />
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-6">
            <div className="relative aspect-[4/3] overflow-hidden border border-border bg-stone-light lg:aspect-[4/5]">
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-stone-light p-6 text-center">
                <MapPin className="size-10 text-muted-foreground/40" />
                <p className="mt-3 font-serif text-lg font-medium text-ink">{siteConfig.address.city}, {siteConfig.country}</p>
                <p className="mt-1 text-sm text-muted-foreground">{siteConfig.address.full}</p>
                <a href={siteConfig.address.mapsUrl} target="_blank" rel="noopener noreferrer" className="link-underline mt-4 text-sm font-medium text-ink">Ver no Google Maps<ArrowUpRight className="size-4" /></a>
              </div>
              <div aria-hidden="true" className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"><div className="relative"><div className="size-4 rounded-full bg-ink ring-4 ring-ink/20" /><div className="absolute left-1/2 top-1/2 size-12 -translate-x-1/2 -translate-y-1/2 animate-ping rounded-full bg-ink/20" /></div></div>
            </div>
            <div className="border border-border bg-background p-6">
              <div className="flex items-center gap-2.5"><Clock className="size-5 text-ink" /><h3 className="font-sans text-[0.7rem] font-medium uppercase tracking-[0.22em] text-muted-foreground">Horário de Funcionamento</h3></div>
              <dl className="mt-4 space-y-2">
                {siteConfig.hours.map((h) => (<div key={h.day} className="flex items-center justify-between border-b border-border/60 pb-2 last:border-0 last:pb-0"><dt className="text-sm text-ink">{h.day}</dt><dd className={h.time === "Fechado" ? "text-sm font-medium text-muted-foreground/70" : "text-sm font-medium text-ink"}>{h.time}</dd></div>))}
              </dl>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

function SocialLink({ href, icon: Icon, label }: { href: string; icon: LucideIcon; label: string }) {
  return (<a href={href} target="_blank" rel="noopener noreferrer" aria-label={label} className="inline-flex size-11 items-center justify-center rounded-full border border-border bg-background text-ink transition-all hover:border-ink hover:bg-ink hover:text-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"><Icon className="size-5" /></a>);
}
