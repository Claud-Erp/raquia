"use client";

import * as React from "react";
import dynamic from "next/dynamic";
import useEmblaCarousel from "embla-carousel-react";
import { cn } from "@/lib/utils";
import { Container } from "@/components/raquia";
import { SectionHeader, ServiceCard } from "@/components/shared";
import type { DetailModalData } from "@/components/shared";
import { services } from "@/config/services";
import type { Service } from "@/config/services";
import { ChevronLeft, ChevronRight } from "lucide-react";

const DetailModal = dynamic(
  () => import("@/components/shared").then((m) => m.DetailModal),
  { ssr: false }
);

/**
 * Services — secção "Os nossos serviços" em carrossel premium.
 *
 * Carrossel horizontal com 7 cards de serviço (altura igual):
 * - Desktop: 3 cards visíveis por slide (scroll por 1)
 * - Tablet: 2 cards visíveis
 * - Mobile: 1 card visível
 *
 * Click num card abre modal com detalhes do serviço.
 *
 * Controlos:
 * - Setas laterais (desktop) com hover invertido
 * - Indicadores (pontos) em baixo com contador
 * - Drag/swipe nativo do embla (mobile)
 * - Teclado acessível
 */
export function Services() {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: "start",
    loop: false,
    dragFree: false,
    containScroll: "trimSnaps",
  });

  const [selected, setSelected] = React.useState(0);
  const [scrollSnaps, setScrollSnaps] = React.useState<number[]>([]);
  const [canPrev, setCanPrev] = React.useState(false);
  const [canNext, setCanNext] = React.useState(false);

  // Estado do modal
  const [modalData, setModalData] = React.useState<DetailModalData | null>(null);
  const [modalOpen, setModalOpen] = React.useState(false);

  const handleCardClick = React.useCallback((service: Service) => {
    const sections = [
      { title: "Características", items: service.details.features },
      { title: "Aplicações", items: service.details.applications },
    ];
    if (service.details.materials && service.details.materials.length > 0) {
      sections.push({ title: "Materiais", items: service.details.materials });
    }

    setModalData({
      title: service.title,
      meta: "Serviço",
      longDescription: service.longDescription,
      image: service.image,
      imageAlt: service.imageAlt,
      sections,
      whatsappMessage: `Olá! Vim pelo site da RAQUIA GRÁFICA e gostaria de saber mais sobre o serviço: ${service.title}.`,
    });
    setModalOpen(true);
  }, []);

  const onSelect = React.useCallback(() => {
    if (!emblaApi) return;
    setSelected(emblaApi.selectedScrollSnap());
    setCanPrev(emblaApi.canScrollPrev());
    setCanNext(emblaApi.canScrollNext());
  }, [emblaApi]);

  React.useEffect(() => {
    if (!emblaApi) return;
    setScrollSnaps(emblaApi.scrollSnapList());
    onSelect();
    emblaApi.on("select", onSelect);
    emblaApi.on("reInit", onSelect);

    const onResize = () => {
      emblaApi.reInit();
      onSelect();
    };
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      emblaApi.off("select", onSelect);
      emblaApi.off("reInit", onSelect);
    };
  }, [emblaApi, onSelect]);

  const scrollTo = React.useCallback(
    (index: number) => emblaApi?.scrollTo(index),
    [emblaApi]
  );
  const scrollPrev = React.useCallback(
    () => emblaApi?.scrollPrev(),
    [emblaApi]
  );
  const scrollNext = React.useCallback(
    () => emblaApi?.scrollNext(),
    [emblaApi]
  );

  return (
    <section
      id="servicos"
      aria-label="Serviços da RAQUIA GRÁFICA"
      className="scroll-mt-20 bg-off-white py-20 lg:py-28"
    >
      <Container variant="wide">
        <SectionHeader
          eyebrow="Os nossos serviços"
          title={
            <>
              Soluções completas de{" "}
              <span className="italic font-normal text-gradient-ink">
                impressão
              </span>{" "}
              e comunicação visual
            </>
          }
          description="Apoiamos empresas, instituições e particulares na criação de materiais que comunicam com impacto e profissionalismo."
          link={{
            label: "Ver todos os serviços",
            href: "/servicos-raquia-grafica.pdf",
            external: true,
          }}
        />
      </Container>

      {/* Carrossel — full-bleed com padding alinhado ao container */}
      <div className="relative mt-12">
        <Container variant="wide">
          {/* Header do carrossel: setas + contador (desktop) */}
          <div className="mb-6 flex items-center justify-end gap-3">
            <span className="mr-auto font-sans text-xs uppercase tracking-[0.22em] text-muted-foreground">
              {String(selected + 1).padStart(2, "0")} /{" "}
              {String(scrollSnaps.length).padStart(2, "0")}
            </span>
            <button
              type="button"
              onClick={scrollPrev}
              disabled={!canPrev}
              aria-label="Serviço anterior"
              className={cn(
                "inline-flex size-11 items-center justify-center rounded-full border transition-all",
                canPrev
                  ? "border-border bg-background text-ink hover:bg-ink hover:text-paper"
                  : "border-border bg-background text-muted-foreground/40 cursor-not-allowed"
              )}
            >
              <ChevronLeft className="size-5" />
            </button>
            <button
              type="button"
              onClick={scrollNext}
              disabled={!canNext}
              aria-label="Próximo serviço"
              className={cn(
                "inline-flex size-11 items-center justify-center rounded-full border transition-all",
                canNext
                  ? "border-border bg-background text-ink hover:bg-ink hover:text-paper"
                  : "border-border bg-background text-muted-foreground/40 cursor-not-allowed"
              )}
            >
              <ChevronRight className="size-5" />
            </button>
          </div>
        </Container>

        {/* Viewport do embla — overflow hidden, padding alinhado */}
        <div
          ref={emblaRef}
          className="overflow-hidden"
        >
          <div className="flex pl-5 sm:pl-6 lg:pl-8 pr-5 sm:pr-6 lg:pr-8">
            {services.map((service) => (
              <div
                key={service.id}
                className={cn(
                  "min-w-0 shrink-0 grow-0 basis-full pl-4 first:pl-0 sm:basis-1/2 lg:basis-1/3",
                  "sm:pl-4 sm:first:pl-0"
                )}
              >
                <ServiceCard service={service} onClick={handleCardClick} />
              </div>
            ))}
          </div>
        </div>

        {/* Indicadores (pontos) — mobile */}
        <Container variant="wide">
          <div className="mt-8 flex items-center justify-center gap-2 lg:hidden">
            {scrollSnaps.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => scrollTo(i)}
                aria-label={`Ir para o slide ${i + 1}`}
                className={cn(
                  "h-2 transition-all duration-300",
                  i === selected ? "w-8 bg-ink" : "w-2 bg-border"
                )}
              />
            ))}
          </div>
        </Container>
      </div>

      {/* Modal de detalhes do serviço */}
      <DetailModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        data={modalData}
      />
    </section>
  );
}
