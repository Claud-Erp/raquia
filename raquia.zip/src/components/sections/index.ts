/**
 * Barrel export das secções da home.
 */
export { Hero } from "./hero";
export { TrustIndicators } from "./trust-indicators";
export { Services } from "./services";
export { Products } from "./products";
export { About } from "./about";
export { Portfolio } from "./portfolio";
export { QuoteCTA } from "./quote-cta";
export { Contact } from "./contact";
