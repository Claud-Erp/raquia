"use client";

import * as React from "react";
import dynamic from "next/dynamic";
import Image from "next/image";
import { Container, Eyebrow, RaquiaButton } from "@/components/raquia";
import { Stats, RevealOnScroll } from "@/components/shared";
import type { DetailModalData } from "@/components/shared";
import { companyInfo, companyAbout } from "@/config/company";
import { ArrowRight } from "lucide-react";

const DetailModal = dynamic(
  () => import("@/components/shared").then((m) => m.DetailModal),
  { ssr: false }
);

/**
 * About — secção "Sobre a Raquia".
 *
 * Estrutura split (desktop):
 *   ┌──────────────────────┬───────────────────────┐
 *   │                      │ Eyebrow               │
 *   │                      │ Headline (serif)      │
 *   │   Imagem premium     │ Descrição             │
 *   │   institucional      │ CTA → abre modal      │
 *   │                      │ ──────                │
 *   │                      │ Stats (3 contadores)  │
 *   └──────────────────────┴───────────────────────┘
 *
 * Mobile: imagem no topo → conteúdo → stats
 *
 * CTA "Conheça a Raquia" abre modal com informações institucionais
 * (missão, visão, valores) + CTAs de orçamento/WhatsApp.
 */
export function About() {
  const [modalOpen, setModalOpen] = React.useState(false);

  const handleOpenModal = React.useCallback(() => {
    setModalOpen(true);
  }, []);

  const modalData: DetailModalData = React.useMemo(
    () => ({
      title: "RAQUIA GRÁFICA",
      meta: companyAbout.meta,
      longDescription: companyAbout.longDescription,
      image: companyInfo.image,
      imageAlt: companyInfo.imageAlt,
      sections: companyAbout.sections,
      whatsappMessage:
        "Olá! Vim pelo site da RAQUIA GRÁFICA e gostaria de saber mais sobre a empresa.",
    }),
    []
  );

  return (
    <section
      id="sobre"
      aria-label="Sobre a RAQUIA GRÁFICA"
      className="scroll-mt-20 bg-off-white py-20 lg:py-28"
    >
      <Container variant="wide">
        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-2 lg:gap-16 xl:gap-20">
          {/* ===================== COLUNA IMAGEM ===================== */}
          <div className="relative order-1 lg:order-1">
            <RevealOnScroll animation="scale-in" duration={900}>
              <figure className="relative">
                <div className="relative aspect-[4/5] w-full overflow-hidden bg-stone-light sm:aspect-[5/6]">
                  <Image
                    src={companyInfo.image}
                    alt={companyInfo.imageAlt}
                    fill
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    className="img-premium"
                  />
                </div>

                {/* Badge "10 Anos" decorativo (canto superior direito) */}
                <div
                  aria-hidden="true"
                  className="absolute -right-3 -top-3 z-10 hidden h-20 w-20 border border-border bg-background sm:block lg:h-24 lg:w-24"
                >
                  <div className="flex h-full w-full flex-col items-center justify-center">
                    <span className="font-serif text-2xl font-semibold text-ink lg:text-3xl">
                      10
                    </span>
                    <span className="font-sans text-[0.55rem] uppercase tracking-[0.2em] text-muted-foreground">
                      Anos
                    </span>
                  </div>
                </div>

                {/* Legenda flutuante */}
                <figcaption className="mt-4 flex items-center justify-between gap-4">
                  <p className="font-sans text-[0.7rem] uppercase tracking-[0.18em] text-muted-foreground">
                    {companyInfo.imageCaption}
                  </p>
                  <span className="hidden font-serif text-sm italic text-muted-foreground sm:block">
                    — RAQUIA Gráfica
                  </span>
                </figcaption>
              </figure>
            </RevealOnScroll>
          </div>

          {/* ===================== COLUNA CONTEÚDO ===================== */}
          <div className="order-2 lg:order-2">
            <RevealOnScroll animation="fade-left" delay={100}>
              <Eyebrow withLine>{companyInfo.eyebrow}</Eyebrow>
            </RevealOnScroll>

            <RevealOnScroll animation="fade-left" delay={200}>
              <h2 className="mt-6 font-serif font-semibold leading-[1] tracking-[-0.03em] text-ink">
                <span className="block text-4xl sm:text-5xl lg:text-6xl">
                  {companyInfo.headlineLine1}
                </span>
                <span className="mt-1 block text-4xl italic font-medium text-gradient-ink sm:text-5xl lg:text-6xl">
                  {companyInfo.headlineLine2}
                </span>
              </h2>
            </RevealOnScroll>

            <RevealOnScroll animation="fade-left" delay={300}>
              <p className="mt-7 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
                {companyInfo.description}
              </p>
            </RevealOnScroll>

            <RevealOnScroll animation="fade-left" delay={400}>
              <div className="mt-8">
                <RaquiaButton
                  variant="primary"
                  size="lg"
                  onClick={handleOpenModal}
                >
                  {companyInfo.cta.label}
                  <ArrowRight className="size-4" />
                </RaquiaButton>
              </div>
            </RevealOnScroll>

            {/* Separador */}
            <div className="my-10 h-px w-full bg-border" />

            {/* Estatísticas animadas */}
            <Stats />
          </div>
        </div>
      </Container>

      {/* Modal de detalhes institucionais */}
      <DetailModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        data={modalData}
      />
    </section>
  );
}
