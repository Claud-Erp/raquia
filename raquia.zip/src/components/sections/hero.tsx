"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { Container, RaquiaButton, Eyebrow } from "@/components/raquia";
import { TrustIndicators } from "./trust-indicators";
import { heroSlides } from "@/config/hero";
import { useHeroCarousel } from "@/hooks/use-hero-carousel";
import { buildWhatsAppUrl, defaultWhatsAppMessage } from "@/lib/whatsapp";
import { ArrowRight, ArrowUpRight, MessageCircle, ChevronLeft, ChevronRight } from "lucide-react";

/**
 * Hero RAQUIA GRÁFICA — carrossel de slides premium.
 *
 * Estrutura (desktop): split 2 colunas
 *   ┌─────────────────────┬────────────────────────┐
 *   │ Eyebrow             │                        │
 *   │ HEADLINE serif      │   Imagem premium       │
 *   │ Subtitle            │   (carrossel)          │
 *   │ 2 CTAs              │                        │
 *   │ Trust indicators    │                        │
 *   └─────────────────────┴────────────────────────┘
 *
 * Carrossel:
 * - 3 slides (cada um com eyebrow, headline, subtitle, imagem próprios)
 * - Auto-play 6s (pausa no hover/focus)
 * - Navegação: setas laterais + indicadores (pontos) em baixo
 * - Transição suave crossfade na imagem + slide no texto
 * - Respeita prefers-reduced-motion
 * - CTAs e trust indicators são fixos (não mudam por slide)
 * - Acessível: aria-labels, rotação anunciada via aria-live
 */
export function Hero() {
  const { current, next, prev, goTo, pause, resume } = useHeroCarousel(
    heroSlides.length,
    6000
  );

  const activeSlide = heroSlides[current];

  return (
    <section
      id="inicio"
      aria-label="Apresentação RAQUIA GRÁFICA"
      className="relative w-full overflow-hidden bg-background pt-28 pb-16 lg:pt-36 lg:pb-24 scroll-mt-20"
      onMouseEnter={pause}
      onMouseLeave={resume}
      onFocus={pause}
      onBlur={resume}
    >
      {/* Decoração lateral: número de secção vertical (desktop) */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute left-6 top-1/2 hidden -translate-y-1/2 -rotate-90 font-sans text-[0.65rem] uppercase tracking-[0.3em] text-muted-foreground/50 xl:block"
      >
        01 — Início
      </span>

      <Container variant="wide">
        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-12 lg:gap-12 xl:gap-16">
          {/* ===================== COLUNA TEXTO (carrossel) ===================== */}
          <div className="lg:col-span-6 xl:col-span-5">
            <div aria-live="polite" aria-atomic="true">
              {heroSlides.map((slide, i) => (
                <SlideContent
                  key={i}
                  slide={slide}
                  active={i === current}
                  index={i}
                />
              ))}
            </div>

            {/* CTAs — fixos (não mudam por slide) */}
            <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4">
              <RaquiaButton asChild variant="primary" size="lg">
                <Link href="/#orcamento">
                  Solicitar Orçamento
                  <ArrowRight className="size-4" />
                </Link>
              </RaquiaButton>

              <RaquiaButton asChild variant="outline" size="lg">
                <a
                  href={buildWhatsAppUrl(defaultWhatsAppMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Falar connosco no WhatsApp (abre numa nova aba)"
                >
                  <MessageCircle className="size-4" />
                  Falar no WhatsApp
                </a>
              </RaquiaButton>
            </div>

            {/* Trust indicators — fixos */}
            <div className="mt-10">
              <TrustIndicators />
            </div>

            {/* Indicadores do carrossel (pontos) */}
            <div
              className="mt-10 flex items-center gap-2"
              role="tablist"
              aria-label="Slides do Hero"
            >
              {heroSlides.map((_, i) => (
                <button
                  key={i}
                  role="tab"
                  aria-selected={i === current}
                  aria-label={`Ir para o slide ${i + 1}`}
                  onClick={() => goTo(i)}
                  className={cn(
                    "group relative h-2 transition-all duration-300",
                    i === current ? "w-10 bg-ink" : "w-2 bg-border hover:bg-muted-foreground"
                  )}
                >
                  <span className="sr-only">Slide {i + 1}</span>
                </button>
              ))}
              <span className="ml-3 font-sans text-xs tabular-nums text-muted-foreground">
                {String(current + 1).padStart(2, "0")} / {String(heroSlides.length).padStart(2, "0")}
              </span>
            </div>
          </div>

          {/* ===================== COLUNA IMAGEM (carrossel) ===================== */}
          <div className="relative lg:col-span-6 xl:col-span-7">
            <div className="relative">
              {/* Stack de imagens com crossfade */}
              <div className="relative aspect-[4/5] w-full overflow-hidden bg-stone-light sm:aspect-[5/6] lg:aspect-[5/6]">
                {heroSlides.map((slide, i) => (
                  <Image
                    key={i}
                    src={slide.image}
                    alt={i === current ? slide.imageAlt : ""}
                    fill
                    priority={i === 0}
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 90vw, 55vw"
                    className={cn(
                      "img-premium transition-opacity duration-700 ease-out",
                      i === current ? "opacity-100" : "opacity-0"
                    )}
                    aria-hidden={i !== current}
                  />
                ))}
              </div>

              {/* Badge "10 Anos" decorativo */}
              <div
                aria-hidden="true"
                className="absolute -right-3 -top-3 z-10 hidden h-20 w-20 border border-border bg-background sm:block lg:h-24 lg:w-24"
              >
                <div className="flex h-full w-full flex-col items-center justify-center">
                  <span className="font-serif text-2xl font-semibold text-ink lg:text-3xl">
                    10
                  </span>
                  <span className="font-sans text-[0.55rem] uppercase tracking-[0.2em] text-muted-foreground">
                    Anos
                  </span>
                </div>
              </div>

              {/* Setas de navegação (desktop, sobre a imagem) */}
              <button
                type="button"
                onClick={prev}
                aria-label="Slide anterior"
                className="absolute left-4 top-1/2 z-20 hidden size-11 -translate-y-1/2 items-center justify-center rounded-full border border-border bg-background/80 text-ink backdrop-blur-sm transition-all hover:bg-ink hover:text-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring lg:flex"
              >
                <ChevronLeft className="size-5" />
              </button>
              <button
                type="button"
                onClick={next}
                aria-label="Próximo slide"
                className="absolute right-4 top-1/2 z-20 hidden size-11 -translate-y-1/2 items-center justify-center rounded-full border border-border bg-background/80 text-ink backdrop-blur-sm transition-all hover:bg-ink hover:text-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring lg:flex"
              >
                <ChevronRight className="size-5" />
              </button>

              {/* Legenda flutuante */}
              <figcaption className="mt-4 flex items-center justify-between gap-4">
                <p
                  key={activeSlide.caption}
                  className="font-sans text-[0.7rem] uppercase tracking-[0.18em] text-muted-foreground animate-fade-in"
                >
                  {activeSlide.caption}
                </p>
                <span className="hidden font-serif text-sm italic text-muted-foreground sm:block">
                  — RAQUIA Gráfica
                </span>
              </figcaption>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

/**
 * Conteúdo textual de um slide (eyebrow + headline + subtitle).
 *
 * Abordagem: renderiza apenas o slide activo (key muda com o índice),
 * disparando a animação fade-up a cada mudança. Isto evita texto
 * fantasma sobreposto e garante uma transição limpa.
 */
function SlideContent({
  slide,
  active,
  index,
}: {
  slide: (typeof heroSlides)[number];
  active: boolean;
  index: number;
}) {
  if (!active) return null;

  return (
    <div
      key={index}
      className="animate-fade-up"
      aria-hidden={!active}
    >
      <Eyebrow withLine>{slide.eyebrow}</Eyebrow>

      <h1 className="mt-6 font-serif font-semibold leading-[0.98] tracking-[-0.03em] text-ink">
        <span className="block text-4xl sm:text-5xl lg:text-6xl xl:text-[4.5rem]">
          {slide.line1}
        </span>
        <span className="mt-1 block text-4xl italic font-medium text-gradient-ink sm:text-5xl lg:text-6xl xl:text-[4.5rem]">
          {slide.line2}
        </span>
      </h1>

      <p className="mt-7 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
        {slide.subtitle}
      </p>
    </div>
  );
}
