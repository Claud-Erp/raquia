import { cn } from "@/lib/utils";
import { trustIndicators, type TrustIndicator } from "@/config/hero";

/**
 * TrustIndicators — barra de 3 indicadores de confiança abaixo do CTA.
 *
 * Layout: separados por linha vertical subtil no desktop,
 * empilhados no mobile. Cada item tem um símbolo geométrico
 * (◆ ◷ ▣) + label.
 */
interface TrustIndicatorsProps {
  items?: TrustIndicator[];
  /** Variante de cor para fundos escuros */
  variant?: "default" | "light";
  className?: string;
}

export function TrustIndicators({
  items = trustIndicators,
  variant = "default",
  className,
}: TrustIndicatorsProps) {
  const isLight = variant === "light";

  return (
    <ul
      className={cn(
        "flex flex-wrap items-center gap-x-6 gap-y-3",
        className
      )}
    >
      {items.map((item, i) => (
        <li
          key={item.label}
          className={cn(
            "flex items-center gap-2.5",
            i > 0 &&
              "lg:before:absolute lg:before:left-[-12px] lg:before:top-1/2 lg:before:h-4 lg:before:-translate-y-1/2 lg:before:w-px",
            i > 0 &&
              (isLight
                ? "lg:before:bg-white/20"
                : "lg:before:bg-border")
          )}
        >
          <span
            aria-hidden="true"
            className={cn(
              "text-sm leading-none",
              isLight ? "text-white" : "text-ink"
            )}
          >
            {item.symbol}
          </span>
          <span
            className={cn(
              "text-xs font-medium tracking-wide sm:text-[0.8rem]",
              isLight ? "text-white/80" : "text-muted-foreground"
            )}
          >
            {item.label}
          </span>
        </li>
      ))}
    </ul>
  );
}
