"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { cn } from "@/lib/utils";
import { quoteFormSchema, type QuoteFormValues } from "@/lib/quote-schema";
import { serviceTypes, productOptions, deadlineOptions, fileUploadConfig } from "@/config/quote";
import { RaquiaButton, Eyebrow } from "@/components/raquia";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRight, CheckCircle2, Upload, X, Loader2, AlertCircle } from "lucide-react";

type Status = "idle" | "loading" | "success" | "error";

const darkFieldClasses = "h-12 rounded-sm border-white/20 bg-white/5 text-paper placeholder:text-white/40 focus-visible:border-white/40 focus-visible:ring-white/20";
const darkTextareaClasses = "min-h-[120px] rounded-sm border-white/20 bg-white/5 text-paper placeholder:text-white/40 focus-visible:border-white/40 focus-visible:ring-white/20";
const darkSelectClasses = "h-12 rounded-sm border-white/20 bg-white/5 text-paper focus-visible:border-white/40 focus-visible:ring-white/20";

export function QuoteForm() {
  const [status, setStatus] = React.useState<Status>("idle");
  const [fileName, setFileName] = React.useState<string>("");
  const [submitError, setSubmitError] = React.useState<string>("");

  const form = useForm<QuoteFormValues>({
    resolver: zodResolver(quoteFormSchema),
    defaultValues: { nome:"", empresa:"", telefone:"", email:"", tipoServico:"", produto:"", quantidade:1, prazo:"", descricao:"", ficheiro:undefined, observacoes:"", consentimento:false },
  });

  const onSubmit = async (values: QuoteFormValues) => {
    setStatus("loading");
    setSubmitError("");
    try {
      const payload = { ...values, ficheiro: values.ficheiro ? { name: values.ficheiro.name, size: values.ficheiro.size, type: values.ficheiro.type } : undefined };
      const response = await fetch("/api/quote", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Erro ao enviar pedido");
      setStatus("success");
      form.reset();
      setFileName("");
    } catch (err) {
      setStatus("error");
      setSubmitError(err instanceof Error ? err.message : "Ocorreu um erro ao enviar o pedido. Tente novamente ou contacte-nos via WhatsApp.");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) { setFileName(file.name); form.setValue("ficheiro", file, { shouldValidate: true }); }
    else { setFileName(""); form.setValue("ficheiro", undefined); }
  };

  const handleRemoveFile = () => {
    setFileName(""); form.setValue("ficheiro", undefined);
    const input = document.getElementById("ficheiro") as HTMLInputElement;
    if (input) input.value = "";
  };

  if (status === "success") {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="mb-6 flex size-16 items-center justify-center rounded-full bg-paper/10">
          <CheckCircle2 className="size-9 text-paper" />
        </div>
        <Eyebrow variant="light" className="mb-3 justify-center">Pedido enviado</Eyebrow>
        <h3 className="font-serif text-3xl font-medium text-paper sm:text-4xl">Obrigado pelo seu pedido!</h3>
        <p className="mt-4 max-w-md text-base leading-relaxed text-white/60">Recebemos a sua solicitação de orçamento. A nossa equipa irá analisar o pedido e entrar em contacto consigo brevemente, normalmente em até 24 horas úteis.</p>
        <div className="mt-8"><RaquiaButton variant="light" size="lg" onClick={() => setStatus("idle")}>Enviar novo pedido</RaquiaButton></div>
      </div>
    );
  }

  return (
    <div className="relative">
      {status === "error" && submitError && (
        <div className="mb-6 flex items-start gap-3 border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
          <AlertCircle className="mt-0.5 size-4 shrink-0" /><p>{submitError}</p>
        </div>
      )}
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5" noValidate>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <FormField control={form.control} name="nome" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Nome <span className="text-destructive">*</span></FormLabel><FormControl><Input {...field} placeholder="O seu nome" className={darkFieldClasses} disabled={status === "loading"} /></FormControl><FormMessage /></FormItem>)} />
            <FormField control={form.control} name="empresa" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Empresa</FormLabel><FormControl><Input {...field} placeholder="Nome da empresa (opcional)" className={darkFieldClasses} disabled={status === "loading"} /></FormControl><FormMessage /></FormItem>)} />
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <FormField control={form.control} name="telefone" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Telefone <span className="text-destructive">*</span></FormLabel><FormControl><Input {...field} type="tel" placeholder="+244 9XX XXX XXX" className={darkFieldClasses} disabled={status === "loading"} /></FormControl><FormMessage /></FormItem>)} />
            <FormField control={form.control} name="email" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Email <span className="text-destructive">*</span></FormLabel><FormControl><Input {...field} type="email" placeholder="email@exemplo.com" className={darkFieldClasses} disabled={status === "loading"} /></FormControl><FormMessage /></FormItem>)} />
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <FormField control={form.control} name="tipoServico" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Tipo de serviço <span className="text-destructive">*</span></FormLabel><Select onValueChange={field.onChange} defaultValue={field.value} disabled={status === "loading"}><FormControl><SelectTrigger className={darkSelectClasses}><SelectValue placeholder="Seleccione um serviço" /></SelectTrigger></FormControl><SelectContent className="bg-ink-soft border-white/20 text-paper">{serviceTypes.map((s) => (<SelectItem key={s} value={s} className="focus:bg-white/10 focus:text-paper">{s}</SelectItem>))}</SelectContent></Select><FormMessage /></FormItem>)} />
            <FormField control={form.control} name="produto" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Produto pretendido <span className="text-destructive">*</span></FormLabel><Select onValueChange={field.onChange} defaultValue={field.value} disabled={status === "loading"}><FormControl><SelectTrigger className={darkSelectClasses}><SelectValue placeholder="Seleccione um produto" /></SelectTrigger></FormControl><SelectContent className="bg-ink-soft border-white/20 text-paper">{productOptions.map((p) => (<SelectItem key={p} value={p} className="focus:bg-white/10 focus:text-paper">{p}</SelectItem>))}</SelectContent></Select><FormMessage /></FormItem>)} />
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
            <FormField control={form.control} name="quantidade" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Quantidade <span className="text-destructive">*</span></FormLabel><FormControl><Input {...field} type="number" min={1} placeholder="Ex: 500" className={darkFieldClasses} disabled={status === "loading"} onChange={(e) => field.onChange(e.target.valueAsNumber)} /></FormControl><FormMessage /></FormItem>)} />
            <FormField control={form.control} name="prazo" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Prazo <span className="text-destructive">*</span></FormLabel><Select onValueChange={field.onChange} defaultValue={field.value} disabled={status === "loading"}><FormControl><SelectTrigger className={darkSelectClasses}><SelectValue placeholder="Seleccione um prazo" /></SelectTrigger></FormControl><SelectContent className="bg-ink-soft border-white/20 text-paper">{deadlineOptions.map((d) => (<SelectItem key={d} value={d} className="focus:bg-white/10 focus:text-paper">{d}</SelectItem>))}</SelectContent></Select><FormMessage /></FormItem>)} />
          </div>
          <FormField control={form.control} name="descricao" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Descrição do projecto <span className="text-destructive">*</span></FormLabel><FormControl><Textarea {...field} placeholder="Descreva o seu projecto: formato, cores, materiais, acabamentos pretendidos..." className={darkTextareaClasses} disabled={status === "loading"} /></FormControl><FormMessage /></FormItem>)} />
          <FormField control={form.control} name="ficheiro" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Anexar ficheiro (opcional)</FormLabel><FormControl><div className="space-y-2">{fileName ? (<div className="flex items-center justify-between gap-3 border border-white/20 bg-white/5 p-3"><div className="flex min-w-0 items-center gap-2"><Upload className="size-4 shrink-0 text-white/60" /><span className="truncate text-sm text-paper">{fileName}</span></div><button type="button" onClick={handleRemoveFile} aria-label="Remover ficheiro" className="inline-flex size-7 shrink-0 items-center justify-center text-white/60 transition-colors hover:text-destructive" disabled={status === "loading"}><X className="size-4" /></button></div>) : (<label htmlFor="ficheiro" className={cn("flex cursor-pointer flex-col items-center gap-2 border border-dashed border-white/20 bg-white/5 p-6 text-center text-sm text-white/60 transition-colors hover:border-white/40 hover:text-paper", "focus-within:ring-2 focus-within:ring-white/20 focus-within:ring-offset-2 focus-within:ring-offset-ink-soft")}><Upload className="size-5 text-white/60" /><span>Clique para anexar ou arraste um ficheiro</span><span className="block text-xs text-white/40">PDF, JPG, PNG · máx. {fileUploadConfig.maxSizeLabel}</span><input id="ficheiro" type="file" className="sr-only" accept={fileUploadConfig.allowedExtensions.join(",")} onChange={handleFileChange} disabled={status === "loading"} /></label>)}</div></FormControl><FormMessage /></FormItem>)} />
          <FormField control={form.control} name="observacoes" render={({ field }) => (<FormItem><FormLabel className="text-xs uppercase tracking-[0.15em] text-white/60">Observações (opcional)</FormLabel><FormControl><Textarea {...field} placeholder="Informações adicionais relevantes..." className="min-h-[80px] rounded-sm border-white/20 bg-white/5 text-paper placeholder:text-white/40 focus-visible:border-white/40 focus-visible:ring-white/20" disabled={status === "loading"} /></FormControl><FormMessage /></FormItem>)} />
          <FormField control={form.control} name="consentimento" render={({ field }) => (<FormItem><div className="flex items-start gap-3"><FormControl><Checkbox checked={field.value} onCheckedChange={field.onChange} disabled={status === "loading"} className="mt-0.5" /></FormControl><div className="space-y-1"><Label htmlFor="consentimento" className="cursor-pointer text-sm leading-relaxed text-white/70">Aceito a <a href="#" className="text-paper underline underline-offset-4">política de privacidade</a> e autorizo o tratamento dos meus dados para resposta a este pedido de orçamento. <span className="text-destructive">*</span></Label></div></div><FormMessage /></FormItem>)} />
          <RaquiaButton type="submit" variant="light" size="lg" className="w-full" disabled={status === "loading"}>{status === "loading" ? (<><Loader2 className="size-4 animate-spin" />A enviar pedido...</>) : (<>Enviar Pedido<ArrowRight className="size-4" /></>)}</RaquiaButton>
        </form>
      </Form>
    </div>
  );
}
