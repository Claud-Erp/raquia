"use client";

import * as React from "react";
import dynamic from "next/dynamic";
import { Container } from "@/components/raquia";
import { SectionHeader, ProductCard, RevealOnScroll } from "@/components/shared";
import type { DetailModalData } from "@/components/shared";
import { products } from "@/config/products";
import type { Product } from "@/config/products";

const DetailModal = dynamic(
  () => import("@/components/shared").then((m) => m.DetailModal),
  { ssr: false }
);

/**
 * Products — secção "Qualidade em cada detalhe".
 *
 * Grid responsivo de 8 produtos:
 * - Mobile (1 coluna)
 * - Tablet sm-md (2 colunas)
 * - Desktop lg (3 colunas)
 * - Desktop xl+ (4 colunas em linha)
 *
 * Click num card abre modal com detalhes do produto.
 */
export function Products() {
  const [modalData, setModalData] = React.useState<DetailModalData | null>(null);
  const [modalOpen, setModalOpen] = React.useState(false);

  const handleCardClick = React.useCallback((product: Product) => {
    setModalData({
      title: product.name,
      meta: product.category,
      longDescription: product.details.longDescription,
      image: product.image,
      imageAlt: product.imageAlt,
      sections: [
        { title: "Especificações técnicas", items: product.details.specs },
        { title: "Opções de personalização", items: product.details.options },
      ],
      whatsappMessage: `Olá! Vim pelo site da RAQUIA GRÁFICA e gostaria de saber mais sobre o produto: ${product.name}.`,
    });
    setModalOpen(true);
  }, []);

  return (
    <section
      id="produtos"
      aria-label="Produtos da RAQUIA GRÁFICA"
      className="scroll-mt-20 bg-background py-20 lg:py-28"
    >
      <Container variant="wide">
        <SectionHeader
          eyebrow="Produtos"
          title={
            <>
              Qualidade em{" "}
              <span className="italic font-normal text-gradient-ink">
                cada detalhe
              </span>
            </>
          }
          description="Da papelaria corporativa aos brindes personalizados — todos os produtos são executados com materiais premium e acabamento de excelência."
          link={{
            label: "Ver todos os produtos",
            href: "/produtos-raquia-grafica.pdf",
            external: true,
          }}
        />

        {/* Grid de produtos */}
        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-6">
          {products.map((product, i) => (
            <RevealOnScroll
              key={product.id}
              animation="fade-up"
              delay={Math.min(i * 80, 400)}
            >
              <ProductCard product={product} onClick={handleCardClick} />
            </RevealOnScroll>
          ))}
        </div>
      </Container>

      {/* Modal de detalhes do produto */}
      <DetailModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        data={modalData}
      />
    </section>
  );
}
