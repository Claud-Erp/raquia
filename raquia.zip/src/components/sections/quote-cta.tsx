import { Container, Eyebrow, Heading, RaquiaButton } from "@/components/raquia";
import { QuoteForm } from "./quote-form";
import { buildWhatsAppUrl } from "@/lib/whatsapp";
import { quoteWhatsAppMessages } from "@/config/quote";
import { ArrowRight, MessageCircle } from "lucide-react";

export function QuoteCTA() {
  return (
    <section id="orcamento" aria-label="Solicitação de orçamento" className="scroll-mt-20 bg-ink text-paper py-20 lg:py-28">
      <Container variant="wide">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16 xl:gap-20">
          <div className="lg:col-span-5">
            <Eyebrow variant="light" withLine>Orçamento</Eyebrow>
            <Heading level="h2" className="mt-6 text-paper">Solicite o seu <span className="italic font-normal text-gradient-paper">orçamento</span></Heading>
            <p className="mt-6 max-w-md text-base leading-relaxed text-white/60 sm:text-lg">Preencha o formulário e receba uma proposta personalizada. Também pode falar directamente connosco pelo WhatsApp para um atendimento imediato.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href="#quote-form" className="inline-flex h-14 items-center justify-center gap-2 rounded-sm bg-paper px-8 text-base font-medium tracking-wide text-ink transition-all duration-300 hover:bg-white [&_svg]:transition-transform [&_svg]:duration-300 hover:[&_svg]:translate-x-1">Preencher formulário<ArrowRight className="size-4" /></a>
              <RaquiaButton asChild variant="outline-light" size="lg"><a href={buildWhatsAppUrl(quoteWhatsAppMessages.direct)} target="_blank" rel="noopener noreferrer"><MessageCircle className="size-4" />Falar no WhatsApp</a></RaquiaButton>
            </div>
            <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-3">
              {[{label:"Resposta em 24h",value:"Rápida"},{label:"Proposta personalizada",value:"À medida"},{label:"Sem compromisso",value:"Grátis"}].map((item) => (
                <div key={item.label} className="border-l border-white/20 pl-4"><p className="font-sans text-[0.65rem] uppercase tracking-[0.22em] text-white/50">{item.value}</p><p className="mt-1 text-sm text-white/80">{item.label}</p></div>
              ))}
            </div>
          </div>
          <div className="lg:col-span-7" id="quote-form">
            <div className="rounded-sm border border-white/10 bg-ink-soft p-6 sm:p-8 lg:p-10"><QuoteForm /></div>
          </div>
        </div>
      </Container>
    </section>
  );
}
