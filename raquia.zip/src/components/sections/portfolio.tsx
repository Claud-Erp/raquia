"use client";

import * as React from "react";
import dynamic from "next/dynamic";
import { Container } from "@/components/raquia";
import {
  SectionHeader,
  PortfolioFilter,
  PortfolioCard,
} from "@/components/shared";
import { portfolioItems } from "@/config/portfolio";
import type { PortfolioCategory, PortfolioItem } from "@/config/portfolio";

const Lightbox = dynamic(
  () => import("@/components/shared").then((m) => m.Lightbox),
  { ssr: false }
);

/**
 * Portfolio — secção "Trabalhos em destaque".
 *
 * Funcionalidades:
 * - Filtros por categoria (Todos + 6 categorias) com estado activo
 * - Grid responsivo de cards (1/2/3/4 colunas)
 * - Animação de entrada dos cards ao mudar de filtro (key remount)
 * - Lightbox com imagem ampliada + navegação por setas + teclado
 * - Link "Ver todo o portfólio" → orçamento
 */
export function Portfolio() {
  const [activeFilter, setActiveFilter] = React.useState<
    "Todos" | PortfolioCategory
  >("Todos");
  const [lightboxOpen, setLightboxOpen] = React.useState(false);
  const [lightboxIndex, setLightboxIndex] = React.useState(0);

  // Items filtrados pela categoria activa
  const filteredItems = React.useMemo(() => {
    if (activeFilter === "Todos") return portfolioItems;
    return portfolioItems.filter((item) => item.category === activeFilter);
  }, [activeFilter]);

  const handleCardClick = React.useCallback((item: PortfolioItem) => {
    // Encontra o índice no array filtrado para o lightbox navegar correctamente
    const index = filteredItems.findIndex((i) => i.id === item.id);
    setLightboxIndex(index >= 0 ? index : 0);
    setLightboxOpen(true);
  }, [filteredItems]);

  return (
    <section
      id="portfolio"
      aria-label="Portfólio da RAQUIA GRÁFICA"
      className="scroll-mt-20 bg-background py-20 lg:py-28"
    >
      <Container variant="wide">
        <SectionHeader
          eyebrow="Portfólio"
          title={
            <>
              Trabalhos em{" "}
              <span className="italic font-normal text-gradient-ink">
                destaque
              </span>
            </>
          }
          description="Uma seleção de projectos que reflectem o nosso compromisso com a qualidade, criatividade e atenção aos detalhes."
          link={{ label: "Ver todo o portfólio", href: "/#orcamento" }}
        />

        {/* Filtros */}
        <div className="mt-10">
          <PortfolioFilter active={activeFilter} onChange={setActiveFilter} />
        </div>

        {/* Grid de trabalhos — key muda com o filtro para re-disparar animação */}
        <div
          key={activeFilter}
          className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-6"
        >
          {filteredItems.map((item, i) => (
            <div
              key={item.id}
              className="animate-fade-up"
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <PortfolioCard item={item} onClick={handleCardClick} />
            </div>
          ))}
        </div>

        {/* Mensagem se não houver items (teórico, mas defensivo) */}
        {filteredItems.length === 0 && (
          <p className="mt-12 text-center text-sm text-muted-foreground">
            Nenhum trabalho encontrado nesta categoria.
          </p>
        )}
      </Container>

      {/* Lightbox */}
      <Lightbox
        open={lightboxOpen}
        onOpenChange={setLightboxOpen}
        items={filteredItems}
        currentIndex={lightboxIndex}
        onIndexChange={setLightboxIndex}
      />
    </section>
  );
}
