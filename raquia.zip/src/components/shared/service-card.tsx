"use client";

import * as React from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import type { Service } from "@/config/services";
import { ArrowUpRight } from "lucide-react";

/**
 * ServiceCard — card de serviço premium.
 *
 * Estrutura: imagem (topo) + número + título + descrição + seta
 *
 * Altura igual: usa h-full + flex flex-col para que todos os cards
 * do carrossel tenham a mesma altura (a descrição empurra a seta para baixo).
 *
 * Hover (elegante, subtil):
 * - Imagem faz zoom suave (scale 1.05)
 * - Overlay escurece ligeiramente
 * - Borda escurece
 * - Seta desliza para cima-direita
 *
 * Click: abre modal com detalhes do serviço (controlado pelo pai).
 *
 * Acessibilidade:
 * - Todo o card é um botão (button)
 * - aria-label descritivo
 * - Focus visible (ring)
 * - alt descritivo na imagem
 */
interface ServiceCardProps {
  service: Service;
  onClick?: (service: Service) => void;
  className?: string;
}

export function ServiceCard({ service, onClick, className }: ServiceCardProps) {
  return (
    <button
      type="button"
      onClick={() => onClick?.(service)}
      aria-label={`${service.title} — ${service.description}. Saber mais.`}
      className={cn(
        "group flex h-full w-full flex-col overflow-hidden text-left",
        "border border-border bg-card transition-all duration-300",
        "hover:border-foreground/30 hover:shadow-[0_4px_24px_-8px_rgb(10_10_10/0.10),0_2px_6px_-4px_rgb(10_10_10/0.06)]",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
      )}
    >
      {/* ===================== IMAGEM ===================== */}
      <div className="relative aspect-[4/3] overflow-hidden bg-stone-light">
        <Image
          src={service.image}
          alt={service.imageAlt}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, (max-width: 1280px) 33vw, 20vw"
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
        {/* Overlay subtil no hover */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-ink/0 transition-colors duration-300 group-hover:bg-ink/10"
        />

        {/* Número editorial (canto superior esquerdo) */}
        <span
          className="absolute left-4 top-4 font-sans text-xs font-medium tracking-[0.18em] text-paper/90 mix-blend-difference"
          aria-hidden="true"
        >
          {service.number}
        </span>
      </div>

      {/* ===================== CONTEÚDO ===================== */}
      <div className="flex flex-1 flex-col p-5 sm:p-6">
        <h3 className="font-serif text-xl font-medium leading-snug text-ink sm:text-2xl">
          {service.title}
        </h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
          {service.description}
        </p>

        {/* Seta que desliza no hover */}
        <div className="mt-5 flex items-center gap-1.5 text-sm font-medium text-ink">
          <span>Saber mais</span>
          <ArrowUpRight
            className="size-4 transition-transform duration-300 ease-out group-hover:translate-x-1 group-hover:-translate-y-1"
            aria-hidden="true"
          />
        </div>
      </div>
    </button>
  );
}
