import * as React from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { Eyebrow, Heading } from "@/components/raquia";
import { ArrowRight } from "lucide-react";

/**
 * SectionHeader — cabeçalho padrão das secções.
 *
 * Estrutura: Eyebrow + Heading + descrição + link opcional "Ver todos".
 * Reutilizado em Serviços, Produtos, Sobre, Portfólio.
 *
 * Layout: flex column no mobile, flex row no desktop
 * (heading à esquerda, link à direita).
 */
interface SectionHeaderProps {
  eyebrow: string;
  title: React.ReactNode;
  description?: string;
  /** Link opcional no canto direito */
  link?: {
    label: string;
    href: string;
    /** Abrir em nova aba (para PDFs, links externos) */
    external?: boolean;
  };
  /** Variante para fundos escuros */
  variant?: "default" | "light";
  /** Alinhamento do título */
  align?: "left" | "center";
  className?: string;
}

export function SectionHeader({
  eyebrow,
  title,
  description,
  link,
  variant = "default",
  align = "left",
  className,
}: SectionHeaderProps) {
  const isLight = variant === "light";

  return (
    <div
      className={cn(
        "flex flex-col gap-6",
        align === "center" ? "items-center text-center" : "items-start",
        link && "lg:flex-row lg:items-end lg:justify-between",
        className
      )}
    >
      <div className={cn("max-w-2xl", align === "center" && "mx-auto")}>
        <Eyebrow variant={isLight ? "light" : "default"} withLine>
          {eyebrow}
        </Eyebrow>
        <Heading level="h2" className="mt-5">
          {title}
        </Heading>
        {description && (
          <p
            className={cn(
              "mt-5 text-base leading-relaxed sm:text-lg",
              isLight ? "text-white/60" : "text-muted-foreground"
            )}
          >
            {description}
          </p>
        )}
      </div>

      {link && (
        link.external ? (
          <a
            href={link.href}
            target="_blank"
            rel="noopener noreferrer"
            className={cn(
              "link-underline shrink-0 text-sm font-medium",
              isLight ? "text-white" : "text-ink"
            )}
          >
            {link.label}
            <ArrowRight className="size-4" />
          </a>
        ) : (
          <Link
            href={link.href}
            className={cn(
              "link-underline shrink-0 text-sm font-medium",
              isLight ? "text-white" : "text-ink"
            )}
          >
            {link.label}
            <ArrowRight className="size-4" />
          </Link>
        )
      )}
    </div>
  );
}
