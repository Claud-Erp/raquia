"use client";

import * as React from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import type { PortfolioItem } from "@/config/portfolio";
import { ArrowUpRight } from "lucide-react";

/**
 * PortfolioCard — card de trabalho de portfólio premium.
 *
 * Estrutura: imagem (aspect 4/5) com overlay escuro no hover
 * mostrando categoria + título + seta.
 *
 * Click: abre lightbox com a imagem ampliada.
 *
 * Acessibilidade:
 * - É um <button> com aria-label descritivo
 * - Focus visible (ring)
 * - alt descritivo na imagem
 */
interface PortfolioCardProps {
  item: PortfolioItem;
  onClick?: (item: PortfolioItem) => void;
  className?: string;
}

export function PortfolioCard({ item, onClick, className }: PortfolioCardProps) {
  return (
    <button
      type="button"
      onClick={() => onClick?.(item)}
      aria-label={`${item.title} — ${item.category}. Ver imagem ampliada.`}
      className={cn(
        "group relative block w-full overflow-hidden",
        "border border-border bg-card transition-all duration-300",
        "hover:border-foreground/30 hover:shadow-[0_4px_24px_-8px_rgb(10_10_10/0.12)]",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        className
      )}
    >
      {/* ===================== IMAGEM ===================== */}
      <div className="relative aspect-[4/5] overflow-hidden bg-stone-light">
        <Image
          src={item.image}
          alt={item.imageAlt}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, (max-width: 1280px) 33vw, 25vw"
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />

        {/* Overlay escuro no hover */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-ink/0 transition-colors duration-300 group-hover:bg-ink/60"
        />

        {/* Categoria (canto superior esquerdo) — sempre visível */}
        <span className="absolute left-3 top-3 bg-background/90 px-2.5 py-1 font-sans text-[0.6rem] font-medium uppercase tracking-[0.15em] text-ink backdrop-blur-sm">
          {item.category}
        </span>

        {/* Conteúdo que aparece no hover (canto inferior) */}
        <div className="absolute inset-x-0 bottom-0 translate-y-2 p-5 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
          <h3 className="font-serif text-xl font-medium leading-snug text-paper sm:text-2xl">
            {item.title}
          </h3>
          {item.client && (
            <p className="mt-1 font-sans text-[0.7rem] uppercase tracking-[0.18em] text-paper/60">
              {item.client}
            </p>
          )}
          <div className="mt-3 flex items-center gap-1.5 text-sm font-medium text-paper">
            <span>Ver projecto</span>
            <ArrowUpRight
              className="size-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1"
              aria-hidden="true"
            />
          </div>
        </div>
      </div>
    </button>
  );
}
