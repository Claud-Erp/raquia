import { cn } from "@/lib/utils";
import { AnimatedCounter } from "./animated-counter";
import { stats } from "@/config/company";

/**
 * Stats — bloco de 3 estatísticas com contador animado.
 *
 * Layout: 3 colunas no desktop, empilhado no mobile.
 * Cada stat tem: valor animado (serif grande) + label.
 *
 * Animação: dispara quando entra no viewport (IntersectionObserver).
 */
interface StatsProps {
  /** Variante para fundos escuros */
  variant?: "default" | "light";
  className?: string;
}

export function Stats({ variant = "default", className }: StatsProps) {
  const isLight = variant === "light";

  return (
    <dl
      className={cn(
        "grid grid-cols-1 gap-6 sm:grid-cols-3 sm:gap-8",
        className
      )}
    >
      {stats.map((stat) => (
        <div
          key={stat.label}
          className={cn(
            "relative border-l pl-4 sm:pl-5",
            isLight ? "border-white/20" : "border-border"
          )}
        >
          <dt
            className={cn(
              "font-sans text-[0.65rem] font-medium uppercase tracking-[0.22em]",
              isLight ? "text-white/60" : "text-muted-foreground"
            )}
          >
            {stat.label}
          </dt>
          <dd
            className={cn(
              "mt-2 font-serif text-4xl font-semibold tracking-[-0.02em] sm:text-5xl",
              isLight ? "text-paper" : "text-ink"
            )}
          >
            <AnimatedCounter
              value={stat.value}
              prefix={stat.prefix}
              suffix={stat.suffix}
            />
          </dd>
        </div>
      ))}
    </dl>
  );
}
