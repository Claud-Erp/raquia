"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * AnimatedCounter — contador que anima de 0 até `value` quando entra no viewport.
 *
 * Usa IntersectionObserver para disparar a animação on-scroll.
 * Respeita prefers-reduced-motion (mostra valor final imediatamente).
 *
 * Props:
 * - value: valor numérico final
 * - prefix/suffix: caracteres não animados (ex: "+", "%")
 * - duration: duração da animação em ms (default 2000)
 * - className: classes adicionais
 */
interface AnimatedCounterProps {
  value: number;
  prefix?: string;
  suffix?: string;
  duration?: number;
  className?: string;
}

export function AnimatedCounter({
  value,
  prefix,
  suffix,
  duration = 2000,
  className,
}: AnimatedCounterProps) {
  const [count, setCount] = React.useState(0);
  const [hasAnimated, setHasAnimated] = React.useState(false);
  const ref = React.useRef<HTMLSpanElement>(null);
  // Guardar refs para animação sem recriar o observer
  const valueRef = React.useRef(value);
  const durationRef = React.useRef(duration);

  React.useEffect(() => {
    valueRef.current = value;
    durationRef.current = duration;
  }, [value, duration]);

  // Respeitar prefers-reduced-motion
  const prefersReducedMotion = React.useMemo(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;

    // Se prefere movimento reduzido, mostrar valor final imediatamente
    if (prefersReducedMotion) {
      setCount(valueRef.current);
      setHasAnimated(true);
      return;
    }

    const animateCount = () => {
      const target = valueRef.current;
      const dur = durationRef.current;
      const start = performance.now();
      const animate = (now: number) => {
        const elapsed = now - start;
        const progress = Math.min(elapsed / dur, 1);
        // Easing ease-out cubic para desacelerar no fim
        const eased = 1 - Math.pow(1 - progress, 3);
        setCount(Math.round(eased * target));
        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          setCount(target);
        }
      };
      requestAnimationFrame(animate);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated) {
          setHasAnimated(true);
          animateCount();
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [hasAnimated, prefersReducedMotion]);

  return (
    <span ref={ref} className={cn("tabular-nums", className)}>
      {prefix}
      {count}
      {suffix}
    </span>
  );
}
