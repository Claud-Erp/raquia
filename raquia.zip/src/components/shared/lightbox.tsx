"use client";

import * as React from "react";
import Image from "next/image";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogPortal,
  DialogOverlay,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import type { PortfolioItem } from "@/config/portfolio";
import { ChevronLeft, ChevronRight, X } from "lucide-react";

/**
 * Lightbox — visualizador de imagem ampliada do portfólio.
 *
 * Funcionalidades:
 * - Imagem grande centralizada
 * - Navegação: setas laterais (anterior/próximo)
 * - Contador "01 / 12"
 * - Teclado: Escape fecha, ← → navegam
 * - Fechar ao clicar fora da imagem
 * - Título + categoria + cliente + descrição
 * - Loop infinito
 *
 * Acessibilidade:
 * - DialogTitle + DialogDescription (sr-only) para screen readers
 * - aria-labels nas setas
 * - Focus trap do Radix
 */
interface LightboxProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  items: PortfolioItem[];
  currentIndex: number;
  onIndexChange: (index: number) => void;
}

export function Lightbox({
  open,
  onOpenChange,
  items,
  currentIndex,
  onIndexChange,
}: LightboxProps) {
  const item = items[currentIndex];

  const goPrev = React.useCallback(() => {
    onIndexChange((currentIndex - 1 + items.length) % items.length);
  }, [currentIndex, items.length, onIndexChange]);

  const goNext = React.useCallback(() => {
    onIndexChange((currentIndex + 1) % items.length);
  }, [currentIndex, items.length, onIndexChange]);

  // Navegação por teclado
  React.useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        goPrev();
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        goNext();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, goPrev, goNext]);

  if (!item) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogPortal>
        <DialogOverlay className="bg-ink/90" />
        <DialogContent
          className={cn(
            "max-h-[95vh] w-full max-w-5xl overflow-hidden p-0 gap-0",
            "bg-ink border-none rounded-sm",
            "grid grid-rows-[auto_1fr]"
          )}
          onClick={(e) => {
            // Fecha ao clicar no backdrop (não na imagem/conteúdo)
            if (e.target === e.currentTarget) onOpenChange(false);
          }}
        >
          {/* Header: contador + fechar */}
          <div className="flex items-center justify-between px-5 py-4 sm:px-8">
            <DialogTitle className="sr-only">
              {item.title} — {item.category}
            </DialogTitle>
            <DialogDescription className="sr-only">
              {item.description}
            </DialogDescription>
            <span className="font-sans text-xs uppercase tracking-[0.22em] text-paper/60">
              {String(currentIndex + 1).padStart(2, "0")} /{" "}
              {String(items.length).padStart(2, "0")}
            </span>
            <button
              type="button"
              onClick={() => onOpenChange(false)}
              aria-label="Fechar"
              className="inline-flex size-10 items-center justify-center rounded-full text-paper/80 transition-colors hover:bg-white/10 hover:text-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-paper"
            >
              <X className="size-5" />
            </button>
          </div>

          {/* Imagem + setas de navegação */}
          <div className="relative flex items-center justify-center px-4 pb-4 sm:px-8 sm:pb-8">
            {/* Seta anterior */}
            {items.length > 1 && (
              <button
                type="button"
                onClick={goPrev}
                aria-label="Projecto anterior"
                className="absolute left-1 z-10 inline-flex size-11 items-center justify-center rounded-full text-paper/70 transition-all hover:bg-white/10 hover:text-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-paper sm:left-2"
              >
                <ChevronLeft className="size-6" />
              </button>
            )}

            {/* Imagem ampliada */}
            <div className="relative aspect-[4/3] w-full max-w-3xl overflow-hidden bg-ink-soft">
              <Image
                src={item.image}
                alt={item.imageAlt}
                fill
                sizes="(max-width: 1024px) 100vw, 768px"
                className="object-contain"
              />
            </div>

            {/* Seta próximo */}
            {items.length > 1 && (
              <button
                type="button"
                onClick={goNext}
                aria-label="Próximo projecto"
                className="absolute right-1 z-10 inline-flex size-11 items-center justify-center rounded-full text-paper/70 transition-all hover:bg-white/10 hover:text-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-paper sm:right-2"
              >
                <ChevronRight className="size-6" />
              </button>
            )}
          </div>

          {/* Legenda */}
          <div className="border-t border-white/10 px-5 py-5 sm:px-8 sm:py-6">
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <span className="font-sans text-[0.65rem] font-medium uppercase tracking-[0.22em] text-paper/50">
                {item.category}
              </span>
              {item.client && (
                <span className="font-sans text-[0.65rem] text-paper/40">
                  · {item.client}
                </span>
              )}
            </div>
            <h3 className="mt-2 font-serif text-2xl font-medium text-paper sm:text-3xl">
              {item.title}
            </h3>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-paper/70">
              {item.description}
            </p>
          </div>
        </DialogContent>
      </DialogPortal>
    </Dialog>
  );
}
