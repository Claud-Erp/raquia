"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { portfolioFilters } from "@/config/portfolio";
import type { PortfolioCategory } from "@/config/portfolio";

/**
 * PortfolioFilter — filtros por categoria.
 *
 * Layout horizontal com scroll horizontal em mobile (overflow-x-auto).
 * Estado activo destacado (bg-ink text-paper).
 *
 * Acessibilidade:
 * - role="tablist" + role="tab"
 * - aria-selected no activo
 * - Teclado: focus visible + Enter/Space activa
 */
interface PortfolioFilterProps {
  active: "Todos" | PortfolioCategory;
  onChange: (value: "Todos" | PortfolioCategory) => void;
  className?: string;
}

export function PortfolioFilter({
  active,
  onChange,
  className,
}: PortfolioFilterProps) {
  return (
    <div
      role="tablist"
      aria-label="Filtrar portfólio por categoria"
      className={cn(
        "flex items-center gap-2 overflow-x-auto pb-2",
        "[scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden",
        className
      )}
    >
      {portfolioFilters.map((filter) => {
        const isActive = active === filter.value;
        return (
          <button
            key={filter.value}
            role="tab"
            aria-selected={isActive}
            type="button"
            onClick={() => onChange(filter.value)}
            className={cn(
              "shrink-0 whitespace-nowrap px-4 py-2 text-xs font-medium tracking-wide transition-all duration-200 sm:text-sm",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
              isActive
                ? "bg-ink text-paper"
                : "border border-border bg-background text-muted-foreground hover:border-foreground/30 hover:text-ink"
            )}
          >
            {filter.label}
          </button>
        );
      })}
    </div>
  );
}
