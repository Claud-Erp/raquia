"use client";

import * as React from "react";
import Image from "next/image";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogPortal,
  DialogOverlay,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { RaquiaButton } from "@/components/raquia";
import { buildWhatsAppUrl, defaultWhatsAppMessage } from "@/lib/whatsapp";
import { ArrowRight, MessageCircle, Check } from "lucide-react";

/**
 * DetailModal — modal partilhado para serviços e produtos.
 *
 * Estrutura:
 * - Imagem grande no topo
 * - Categoria/número
 * - Título serif
 * - Descrição longa
 * - Secções de características, aplicações, materiais/opções
 * - CTAs: Solicitar Orçamento + Falar no WhatsApp
 *
 * Acessibilidade:
 * - DialogTitle + DialogDescription para screen readers
 * - Focus trap do Radix
 * - Fecha com Escape
 */

export interface DetailSection {
  /** Título da secção (ex: "Características", "Especificações") */
  title: string;
  /** Lista de items */
  items: string[];
}

export interface DetailModalData {
  /** Título */
  title: string;
  /** Categoria ou número editorial */
  meta: string;
  /** Descrição longa */
  longDescription: string;
  /** Caminho da imagem */
  image: string;
  /** Alt descritivo */
  imageAlt: string;
  /** Secções de detalhes */
  sections: DetailSection[];
  /** Mensagem WhatsApp personalizada */
  whatsappMessage?: string;
}

interface DetailModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  data: DetailModalData | null;
}

export function DetailModal({ open, onOpenChange, data }: DetailModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogPortal>
        <DialogOverlay />
        <DialogContent
          className={cn(
            "max-h-[90vh] w-full max-w-3xl overflow-y-auto p-0 gap-0",
            "bg-background border-border rounded-sm"
          )}
        >
          {data && <DetailModalContent data={data} />}
        </DialogContent>
      </DialogPortal>
    </Dialog>
  );
}

function DetailModalContent({ data }: { data: DetailModalData }) {
  const whatsappMsg =
    data.whatsappMessage ||
    `Olá! Vim pelo site da RAQUIA GRÁFICA e gostaria de saber mais sobre ${data.title}.`;

  return (
    <>
      {/* Imagem hero do modal */}
      <div className="relative aspect-[16/9] w-full overflow-hidden bg-stone-light sm:aspect-[2/1]">
        <Image
          src={data.image}
          alt={data.imageAlt}
          fill
          sizes="(max-width: 768px) 100vw, 768px"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/50 via-ink/20 to-transparent" />

        {/* Título do modal sobre a imagem (sempre visível) */}
        <div className="absolute inset-x-0 bottom-0 p-5 sm:p-8">
          {/* Meta (categoria) acima do título */}
          <span className="mb-2 block font-sans text-[0.65rem] font-medium uppercase tracking-[0.22em] text-paper/80">
            {data.meta}
          </span>
          <DialogTitle className="font-serif text-3xl font-semibold leading-tight tracking-[-0.02em] text-paper drop-shadow-sm sm:text-4xl lg:text-5xl">
            {data.title}
          </DialogTitle>
        </div>
      </div>

      <div className="p-6 sm:p-8 lg:p-10">
        {/* Descrição longa */}
        <DialogDescription className="text-base leading-relaxed text-muted-foreground">
          {data.longDescription}
        </DialogDescription>

        {/* Secções de detalhes */}
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2">
          {data.sections.map((section) => (
            <div key={section.title}>
              <h3 className="font-sans text-[0.7rem] font-medium uppercase tracking-[0.22em] text-muted-foreground">
                {section.title}
              </h3>
              <ul className="mt-3 space-y-2">
                {section.items.map((item, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-sm text-ink">
                    <Check className="mt-0.5 size-4 shrink-0 text-ink" aria-hidden="true" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Separador */}
        <div className="my-8 h-px w-full bg-border" />

        {/* CTAs com hover reforçado */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <RaquiaButton
            asChild
            variant="primary"
            size="lg"
            className="group w-full sm:w-auto"
          >
            <a href="/#orcamento">
              Solicitar Orçamento
              <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1.5" />
            </a>
          </RaquiaButton>
          <RaquiaButton
            asChild
            variant="outline"
            size="lg"
            className="group w-full sm:w-auto"
          >
            <a
              href={buildWhatsAppUrl(whatsappMsg)}
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle className="size-4 transition-transform duration-300 group-hover:scale-110" />
              Falar no WhatsApp
            </a>
          </RaquiaButton>
        </div>
      </div>
    </>
  );
}
