"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

type AnimationType = "fade-up" | "fade-in" | "fade-left" | "fade-right" | "scale-in";

interface RevealOnScrollProps {
  children: React.ReactNode;
  animation?: AnimationType;
  delay?: number;
  duration?: number;
  className?: string;
  threshold?: number;
  as?: React.ElementType;
  disabled?: boolean;
}

export function RevealOnScroll({
  children,
  animation = "fade-up",
  delay = 0,
  duration = 700,
  className,
  threshold = 0.15,
  as: Comp = "div",
  disabled = false,
}: RevealOnScrollProps) {
  const [isVisible, setIsVisible] = React.useState(false);
  const ref = React.useRef<HTMLDivElement>(null);

  const prefersReducedMotion = React.useMemo(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  React.useEffect(() => {
    if (prefersReducedMotion || disabled) { setIsVisible(true); return; }
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => { if (entries[0].isIntersecting) { setIsVisible(true); observer.disconnect(); } },
      { threshold, rootMargin: "0px 0px -50px 0px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [threshold, prefersReducedMotion, disabled]);

  const initialStyles: Record<AnimationType, React.CSSProperties> = {
    "fade-up": { opacity: 0, transform: "translateY(24px)" },
    "fade-in": { opacity: 0 },
    "fade-left": { opacity: 0, transform: "translateX(-24px)" },
    "fade-right": { opacity: 0, transform: "translateX(24px)" },
    "scale-in": { opacity: 0, transform: "scale(0.96)" },
  };
  const visibleStyles: React.CSSProperties = { opacity: 1, transform: "none" };
  const shouldAnimate = !prefersReducedMotion && !disabled;

  return (
    <Comp ref={ref} className={cn(className)} style={shouldAnimate ? { ...initialStyles[animation], transition: `opacity ${duration}ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms, transform ${duration}ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms`, willChange: "opacity, transform", ...(isVisible ? visibleStyles : {}) } : undefined}>
      {children}
    </Comp>
  );
}
