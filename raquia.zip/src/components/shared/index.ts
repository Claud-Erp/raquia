/**
 * Barrel export dos componentes partilhados.
 */
export { SectionHeader } from "./section-header";
export { ServiceCard } from "./service-card";
export { ProductCard } from "./product-card";
export { DetailModal, type DetailModalData, type DetailSection } from "./detail-modal";
export { AnimatedCounter } from "./animated-counter";
export { Stats } from "./stats";
export { PortfolioFilter } from "./portfolio-filter";
export { PortfolioCard } from "./portfolio-card";
export { Lightbox } from "./lightbox";
export { RevealOnScroll } from "./reveal-on-scroll";
