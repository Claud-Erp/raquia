"use client";

import * as React from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import type { Product } from "@/config/products";
import { ArrowUpRight } from "lucide-react";

/**
 * ProductCard — card de produto premium.
 *
 * Estrutura: imagem (topo) + categoria overlay + nome + botão "Ver produto"
 *
 * Hover (elegante, subtil):
 * - Imagem faz zoom suave (scale 1.05)
 * - Overlay escurece ligeiramente
 * - Botão "Ver produto" aparece com seta
 * - Borda escurece
 *
 * Click: abre modal com detalhes do produto (controlado pelo pai).
 *
 * Acessibilidade:
 * - Todo o card é um botão (button)
 * - aria-label descritivo
 * - Focus visible (ring)
 * - alt descritivo na imagem
 */
interface ProductCardProps {
  product: Product;
  onClick?: (product: Product) => void;
  className?: string;
}

export function ProductCard({ product, onClick, className }: ProductCardProps) {
  return (
    <button
      type="button"
      onClick={() => onClick?.(product)}
      aria-label={`${product.name} — ${product.category}. Ver produto.`}
      className={cn(
        "group flex h-full w-full flex-col overflow-hidden text-left",
        "border border-border bg-card transition-all duration-300",
        "hover:border-foreground/30 hover:shadow-[0_4px_24px_-8px_rgb(10_10_10/0.10),0_2px_6px_-4px_rgb(10_10_10/0.06)]",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
      )}
    >
      {/* ===================== IMAGEM ===================== */}
      <div className="relative aspect-square overflow-hidden bg-stone-light">
        <Image
          src={product.image}
          alt={product.imageAlt}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, (max-width: 1280px) 33vw, 25vw"
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
        {/* Overlay subtil no hover */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-ink/0 transition-colors duration-300 group-hover:bg-ink/10"
        />

        {/* Categoria (canto superior esquerdo) — visível sempre */}
        <span className="absolute left-3 top-3 bg-background/90 px-2.5 py-1 font-sans text-[0.6rem] font-medium uppercase tracking-[0.15em] text-ink backdrop-blur-sm">
          {product.category}
        </span>
      </div>

      {/* ===================== CONTEÚDO ===================== */}
      <div className="flex flex-1 flex-col p-4 sm:p-5">
        <h3 className="font-serif text-lg font-medium leading-snug text-ink sm:text-xl">
          {product.name}
        </h3>
        {product.description && (
          <p className="mt-1.5 flex-1 text-xs leading-relaxed text-muted-foreground sm:text-sm">
            {product.description}
          </p>
        )}

        {/* Botão "Ver produto" */}
        <div className="mt-4 flex items-center gap-1.5 text-sm font-medium text-ink">
          <span>Ver produto</span>
          <ArrowUpRight
            className="size-4 transition-transform duration-300 ease-out group-hover:translate-x-1 group-hover:-translate-y-1"
            aria-hidden="true"
          />
        </div>
      </div>
    </button>
  );
}
