import * as React from "react";
import { cn } from "@/lib/utils";
import { Container } from "./container";

/**
 * Section RAQUIA — secção semântica com padding vertical consistente.
 * Inclui <section> para acessibilidade e suporte a fundos dark.
 */
const Section = React.forwardRef<
  HTMLElement,
  React.HTMLAttributes<HTMLElement> & {
    /** Padding vertical: default (py-20 lg:py-28), sm, lg, xl, none */
    spacing?: "none" | "sm" | "default" | "lg" | "xl";
    /** Tipo de fundo */
    surface?: "paper" | "off-white" | "stone-light" | "ink" | "ink-soft";
    /** Largura do container interno */
    container?: "base" | "wide" | "narrow" | "full";
    /** Sem container interno (para layouts full-bleed) */
    bare?: boolean;
  }
>(
  (
    {
      className,
      spacing = "default",
      surface = "paper",
      container = "base",
      bare = false,
      children,
      ...props
    },
    ref
  ) => {
    const spacingCls = {
      none: "",
      sm: "py-12 lg:py-16",
      default: "py-20 lg:py-28",
      lg: "py-24 lg:py-32",
      xl: "py-32 lg:py-40",
    }[spacing];

    const surfaceCls = {
      paper: "bg-background",
      "off-white": "bg-off-white",
      "stone-light": "bg-stone-light",
      ink: "bg-ink text-paper",
      "ink-soft": "bg-ink-soft text-paper",
    }[surface];

    return (
      <section
        ref={ref}
        data-slot="section"
        className={cn("relative w-full", spacingCls, surfaceCls, className)}
        {...props}
      >
        {bare ? children : <Container variant={container}>{children}</Container>}
      </section>
    );
  }
);
Section.displayName = "Section";

export { Section };
