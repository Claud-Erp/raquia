import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Eyebrow — Label editorial uppercase com tracking amplo.
 * Usado acima dos títulos para contexto (ex: "SOBRE A RAQUIA").
 */
const Eyebrow = React.forwardRef<
  HTMLSpanElement,
  React.HTMLAttributes<HTMLSpanElement> & {
    /** Mostrar pequena linha antes do texto */
    withLine?: boolean;
    /** Variante de cor */
    variant?: "default" | "muted" | "light";
  }
>(({ className, withLine = false, variant = "default", children, ...props }, ref) => {
  const colorCls = {
    default: "text-foreground",
    muted: "text-muted-foreground",
    light: "text-white/70",
  }[variant];

  return (
    <span
      ref={ref}
      data-slot="eyebrow"
      className={cn(
        "inline-flex items-center gap-2.5 text-[0.7rem] font-medium uppercase tracking-[0.22em]",
        colorCls,
        className
      )}
      {...props}
    >
      {withLine && (
        <span className="h-px w-8 bg-current opacity-60" aria-hidden="true" />
      )}
      {children}
    </span>
  );
});
Eyebrow.displayName = "Eyebrow";

export { Eyebrow };
