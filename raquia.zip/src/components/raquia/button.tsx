import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * Button RAQUIA — Botão premium com variants editoriais.
 * Estilo: fundo preto sólido + seta, bordas finas, hover inverte cores.
 */
const raquiaButtonVariants = cva(
  "group inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium tracking-wide transition-all duration-300 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
  {
    variants: {
      variant: {
        // Preto sólido — CTA principal
        primary:
          "bg-ink text-paper hover:bg-ink-soft [&_svg]:transition-transform [&_svg]:duration-300 group-hover:[&_svg]:translate-x-1",
        // Outline preto — CTA secundário
        outline:
          "border border-ink bg-transparent text-ink hover:bg-ink hover:text-paper",
        // Outline branco (sobre fundos escuros)
        "outline-light":
          "border border-white/30 bg-transparent text-white hover:border-white hover:bg-white hover:text-ink",
        // Branco sólido (sobre fundos escuros)
        "light":
          "bg-paper text-ink hover:bg-white [&_svg]:transition-transform [&_svg]:duration-300 group-hover:[&_svg]:translate-x-1",
        // Ghost — sem fundo, sem borda
        ghost:
          "bg-transparent text-ink hover:bg-accent",
        // Link com seta animada
        link:
          "bg-transparent text-ink underline-offset-4 hover:underline px-0 h-auto [&_svg]:transition-transform [&_svg]:duration-300 group-hover:[&_svg]:translate-x-1",
      },
      size: {
        default: "h-11 px-6 rounded-sm",
        sm: "h-9 px-4 rounded-sm text-xs",
        lg: "h-14 px-8 rounded-sm text-base",
        xl: "h-16 px-10 rounded-sm text-base",
        icon: "size-11 rounded-sm",
        "icon-sm": "size-9 rounded-sm",
        link: "h-auto px-0",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "default",
    },
  }
);

export interface RaquiaButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof raquiaButtonVariants> {
  asChild?: boolean;
}

const RaquiaButton = React.forwardRef<HTMLButtonElement, RaquiaButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        ref={ref}
        data-slot="raquia-button"
        className={cn(raquiaButtonVariants({ variant, size, className }))}
        {...props}
      />
    );
  }
);
RaquiaButton.displayName = "RaquiaButton";

export { RaquiaButton, raquiaButtonVariants };
