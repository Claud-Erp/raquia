import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Container RAQUIA — wrapper centralizado com largura máxima controlada.
 * Variants: base (7xl), wide (80rem), narrow (3xl), full (sem max-w).
 */
const Container = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    variant?: "base" | "wide" | "narrow" | "full";
  }
>(({ className, variant = "base", ...props }, ref) => {
  const maxW = {
    base: "max-w-7xl",
    wide: "max-w-[80rem]",
    narrow: "max-w-3xl",
    full: "max-w-none",
  }[variant];

  return (
    <div
      ref={ref}
      data-slot="container"
      className={cn(
        "mx-auto w-full px-5 sm:px-6 lg:px-8",
        maxW,
        className
      )}
      {...props}
    />
  );
});
Container.displayName = "Container";

export { Container };
