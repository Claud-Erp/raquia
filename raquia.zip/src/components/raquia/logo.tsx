import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Logo RAQUIA GRÁFICA — wordmark serifado.
 * "RAQUIA" em bold + "GRÁFICA" em light com tracking amplo.
 * Suporta variant light (sobre fundo escuro).
 */
const Logo = React.forwardRef<
  HTMLAnchorElement,
  React.AnchorHTMLAttributes<HTMLAnchorElement> & {
    variant?: "default" | "light";
    /** Mostrar subtítulo "GRÁFICA" */
    withSub?: boolean;
    /** Tamanho */
    size?: "sm" | "md" | "lg";
  }
>(
  (
    {
      className,
      variant = "default",
      withSub = true,
      size = "md",
      href = "/",
      ...props
    },
    ref
  ) => {
    const sizeCls = {
      sm: { main: "text-xl", sub: "text-[0.6rem]" },
      md: { main: "text-2xl", sub: "text-[0.65rem]" },
      lg: { main: "text-3xl", sub: "text-xs" },
    }[size];

    const colorCls =
      variant === "light"
        ? "text-paper"
        : "text-ink";

    const subColorCls =
      variant === "light" ? "text-white/60" : "text-muted-foreground";

    return (
      <a
        ref={ref}
        href={href}
        aria-label="RAQUIA GRÁFICA — Página inicial"
        className={cn(
          "group inline-flex flex-col leading-none tracking-tight transition-opacity hover:opacity-80",
          colorCls,
          className
        )}
        {...props}
      >
        <span className={cn("font-serif font-bold tracking-tight", sizeCls.main)}>
          RAQUIA
        </span>
        {withSub && (
          <span
            className={cn(
              "font-sans font-light uppercase tracking-[0.42em] mt-1",
              sizeCls.sub,
              subColorCls
            )}
          >
            Gráfica
          </span>
        )}
      </a>
    );
  }
);
Logo.displayName = "Logo";

export { Logo };
