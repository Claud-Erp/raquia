import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * Heading RAQUIA — Título serifado (Playfair Display).
 * Hierarquia: display > h1 > h2 > h3 > h4.
 */
const headingVariants = cva("font-serif tracking-[-0.02em] text-balance", {
  variants: {
    level: {
      display: "text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-semibold leading-[0.95]",
      h1: "text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.02]",
      h2: "text-3xl sm:text-4xl lg:text-5xl font-medium leading-[1.08]",
      h3: "text-2xl sm:text-3xl lg:text-4xl font-medium leading-[1.15]",
      h4: "text-xl sm:text-2xl font-medium leading-[1.25]",
      h5: "text-lg sm:text-xl font-medium leading-[1.3]",
    },
  },
  defaultVariants: {
    level: "h2",
  },
});

export interface HeadingProps
  extends React.HTMLAttributes<HTMLHeadingElement>,
    VariantProps<typeof headingVariants> {
  /** Tag HTML renderizada */
  as?: "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
}

const Heading = React.forwardRef<HTMLHeadingElement, HeadingProps>(
  ({ className, level, as: Comp = "h2", ...props }, ref) => {
    return (
      <Comp
        ref={ref}
        data-slot="heading"
        className={cn(headingVariants({ level }), className)}
        {...props}
      />
    );
  }
);
Heading.displayName = "Heading";

export { Heading, headingVariants };
